#include <hxcpp.h>

namespace hx {
const char *__hxcpp_all_files[] = {
#ifdef HXCPP_DEBUGGER
"C:\\HaxeToolkit\\haxe\\std/cpp/Lib.hx",
"C:\\HaxeToolkit\\haxe\\std/cpp/_std/EReg.hx",
"C:\\HaxeToolkit\\haxe\\std/cpp/_std/Std.hx",
"C:\\HaxeToolkit\\haxe\\std/cpp/_std/sys/io/File.hx",
"C:\\HaxeToolkit\\haxe\\std/cpp/_std/sys/io/FileInput.hx",
"C:\\HaxeToolkit\\haxe\\std/haxe/Log.hx",
"C:\\HaxeToolkit\\haxe\\std/haxe/io/Eof.hx",
"Main.hx",
"tryOut/TryOut.hx",
"tryOut/packageLevel02/packageLevel03/DeeplyRootedClass.hx",
#endif
 0 };

const char *__hxcpp_all_files_fullpath[] = {
#ifdef HXCPP_DEBUGGER
"C:\\HaxeToolkit\\haxe\\std\\cpp\\Lib.hx",
"C:\\HaxeToolkit\\haxe\\std\\cpp\\_std\\EReg.hx",
"C:\\HaxeToolkit\\haxe\\std\\cpp\\_std\\Std.hx",
"C:\\HaxeToolkit\\haxe\\std\\cpp\\_std\\sys\\io\\File.hx",
"C:\\HaxeToolkit\\haxe\\std\\cpp\\_std\\sys\\io\\FileInput.hx",
"C:\\HaxeToolkit\\haxe\\std\\haxe\\Log.hx",
"C:\\HaxeToolkit\\haxe\\std\\haxe\\io\\Eof.hx",
"D:\\IO\\HAXE\\_libraries\\phantomExpressionistDevelopmentProj\\src\\Main.hx",
"D:\\IO\\HAXE\\_libraries\\phantomExpressionistDevelopmentProj\\src\\tryOut\\TryOut.hx",
"D:\\IO\\HAXE\\_libraries\\phantomExpressionistDevelopmentProj\\src\\tryOut\\packageLevel02\\packageLevel03\\DeeplyRootedClass.hx",
#endif
 0 };

const char *__hxcpp_all_classes[] = {
#ifdef HXCPP_DEBUGGER
"cpp.Lib",
"EReg",
"Main",
"Std",
"haxe.Log",
"haxe.io.Eof",
"haxe.io.Input",
"sys.io.File",
"sys.io.FileInput",
"tryOut.TryOut",
"tryOut.packageLevel02.packageLevel03.DeeplyRootedClass",
#endif
 0 };
} // namespace hx
void __files__boot() { __hxcpp_set_debugger_info(hx::__hxcpp_all_classes, hx::__hxcpp_all_files_fullpath); }
