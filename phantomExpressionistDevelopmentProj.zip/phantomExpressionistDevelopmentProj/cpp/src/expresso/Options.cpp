#include <hxcpp.h>

#ifndef INCLUDED_expresso_Options
#include <expresso/Options.h>
#endif
namespace expresso{

Void Options_obj::__construct()
{
HX_STACK_FRAME("expresso.Options","new",0x6f107881,"expresso.Options.new","expresso/Options.hx",38,0xf42a3d50)
HX_STACK_THIS(this)
{
	HX_STACK_LINE(38)
	this->set_threadTracking(true);
}
;
	return null();
}

//Options_obj::~Options_obj() { }

Dynamic Options_obj::__CreateEmpty() { return  new Options_obj; }
hx::ObjectPtr< Options_obj > Options_obj::__new()
{  hx::ObjectPtr< Options_obj > _result_ = new Options_obj();
	_result_->__construct();
	return _result_;}

Dynamic Options_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< Options_obj > _result_ = new Options_obj();
	_result_->__construct();
	return _result_;}

bool Options_obj::get_threadTracking( ){
	HX_STACK_FRAME("expresso.Options","get_threadTracking",0xb03f7de9,"expresso.Options.get_threadTracking","expresso/Options.hx",19,0xf42a3d50)
	HX_STACK_THIS(this)
	HX_STACK_LINE(20)
	bool tmp = this->threadTracking;		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(20)
	return tmp;
}


HX_DEFINE_DYNAMIC_FUNC0(Options_obj,get_threadTracking,return )

bool Options_obj::set_threadTracking( bool newThreadTracking){
	HX_STACK_FRAME("expresso.Options","set_threadTracking",0x8ceeb05d,"expresso.Options.set_threadTracking","expresso/Options.hx",24,0xf42a3d50)
	HX_STACK_THIS(this)
	HX_STACK_ARG(newThreadTracking,"newThreadTracking")
	HX_STACK_LINE(25)
	this->threadTracking = newThreadTracking;
	HX_STACK_LINE(26)
	bool tmp = this->get_threadTracking();		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(26)
	return tmp;
}


HX_DEFINE_DYNAMIC_FUNC1(Options_obj,set_threadTracking,return )

Void Options_obj::setOptions( Array< ::String > options){
{
		HX_STACK_FRAME("expresso.Options","setOptions",0xce0665db,"expresso.Options.setOptions","expresso/Options.hx",44,0xf42a3d50)
		HX_STACK_THIS(this)
		HX_STACK_ARG(options,"options")
		HX_STACK_LINE(45)
		bool tmp = (options != null());		HX_STACK_VAR(tmp,"tmp");
		HX_STACK_LINE(45)
		if ((tmp)){
			HX_STACK_LINE(47)
			this->set_threadTracking(false);
			HX_STACK_LINE(49)
			{
				HX_STACK_LINE(49)
				int _g = (int)0;		HX_STACK_VAR(_g,"_g");
				HX_STACK_LINE(49)
				while((true)){
					HX_STACK_LINE(49)
					bool tmp1 = (_g < options->length);		HX_STACK_VAR(tmp1,"tmp1");
					HX_STACK_LINE(49)
					bool tmp2 = !(tmp1);		HX_STACK_VAR(tmp2,"tmp2");
					HX_STACK_LINE(49)
					if ((tmp2)){
						HX_STACK_LINE(49)
						break;
					}
					HX_STACK_LINE(49)
					::String tmp3 = options->__get(_g);		HX_STACK_VAR(tmp3,"tmp3");
					HX_STACK_LINE(49)
					::String option = tmp3;		HX_STACK_VAR(option,"option");
					HX_STACK_LINE(49)
					++(_g);
					HX_STACK_LINE(51)
					::String tmp4 = option;		HX_STACK_VAR(tmp4,"tmp4");
					HX_STACK_LINE(51)
					::String _switch_1 = (tmp4);
					if (  ( _switch_1==HX_HCSTRING("threadTracking","\x21","\xf8","\xaf","\x47")) ||  ( _switch_1==HX_HCSTRING("thread","\xca","\x7a","\xb9","\x8e"))){
						HX_STACK_LINE(54)
						this->set_threadTracking(true);
					}
					else if (  ( _switch_1==HX_HCSTRING("test","\x52","\xc8","\xf9","\x4c")) ||  ( _switch_1==HX_HCSTRING("testing","\xd0","\xc3","\xd6","\xbd")) ||  ( _switch_1==HX_HCSTRING("justForTestingPurposes","\x48","\xe5","\x3d","\x2f"))){
						HX_STACK_LINE(56)
						this->justForTestingPurposes = true;
					}
				}
			}
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(Options_obj,setOptions,(void))


Options_obj::Options_obj()
{
}

Dynamic Options_obj::__Field(const ::String &inName,hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 10:
		if (HX_FIELD_EQ(inName,"setOptions") ) { return setOptions_dyn(); }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"threadTracking") ) { return inCallProp == hx::paccAlways ? get_threadTracking() : threadTracking; }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"get_threadTracking") ) { return get_threadTracking_dyn(); }
		if (HX_FIELD_EQ(inName,"set_threadTracking") ) { return set_threadTracking_dyn(); }
		break;
	case 22:
		if (HX_FIELD_EQ(inName,"justForTestingPurposes") ) { return justForTestingPurposes; }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic Options_obj::__SetField(const ::String &inName,const Dynamic &inValue,hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 14:
		if (HX_FIELD_EQ(inName,"threadTracking") ) { if (inCallProp == hx::paccAlways) return set_threadTracking(inValue);threadTracking=inValue.Cast< bool >(); return inValue; }
		break;
	case 22:
		if (HX_FIELD_EQ(inName,"justForTestingPurposes") ) { justForTestingPurposes=inValue.Cast< bool >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

bool Options_obj::__SetStatic(const ::String &inName,Dynamic &ioValue,hx::PropertyAccess inCallProp)
{
	return false;
}

void Options_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_HCSTRING("threadTracking","\x21","\xf8","\xaf","\x47"));
	outFields->push(HX_HCSTRING("justForTestingPurposes","\x48","\xe5","\x3d","\x2f"));
	super::__GetFields(outFields);
};

#if HXCPP_SCRIPTABLE
static hx::StorageInfo sMemberStorageInfo[] = {
	{hx::fsBool,(int)offsetof(Options_obj,threadTracking),HX_HCSTRING("threadTracking","\x21","\xf8","\xaf","\x47")},
	{hx::fsBool,(int)offsetof(Options_obj,justForTestingPurposes),HX_HCSTRING("justForTestingPurposes","\x48","\xe5","\x3d","\x2f")},
	{ hx::fsUnknown, 0, null()}
};
static hx::StaticInfo *sStaticStorageInfo = 0;
#endif

static ::String sMemberFields[] = {
	HX_HCSTRING("threadTracking","\x21","\xf8","\xaf","\x47"),
	HX_HCSTRING("get_threadTracking","\xea","\xd8","\x49","\xe3"),
	HX_HCSTRING("set_threadTracking","\x5e","\x0b","\xf9","\xbf"),
	HX_HCSTRING("justForTestingPurposes","\x48","\xe5","\x3d","\x2f"),
	HX_HCSTRING("setOptions","\xdc","\x57","\xdd","\x32"),
	::String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(Options_obj::__mClass,"__mClass");
};

#ifdef HXCPP_VISIT_ALLOCS
static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(Options_obj::__mClass,"__mClass");
};

#endif

hx::Class Options_obj::__mClass;

void Options_obj::__register()
{
	hx::Static(__mClass) = new hx::Class_obj();
	__mClass->mName = HX_HCSTRING("expresso.Options","\x0f","\x24","\x70","\x48");
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &Options_obj::__SetStatic;
	__mClass->mMarkFunc = sMarkStatics;
	__mClass->mStatics = hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = hx::Class_obj::dupFunctions(sMemberFields);
	__mClass->mCanCast = hx::TCanCast< Options_obj >;
#ifdef HXCPP_VISIT_ALLOCS
	__mClass->mVisitFunc = sVisitStatics;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = sStaticStorageInfo;
#endif
	hx::RegisterClass(__mClass->mName, __mClass);
}

} // end namespace expresso
