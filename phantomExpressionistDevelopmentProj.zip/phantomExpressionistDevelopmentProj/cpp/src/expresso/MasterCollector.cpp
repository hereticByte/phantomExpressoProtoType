#include <hxcpp.h>

#ifndef INCLUDED_EReg
#include <EReg.h>
#endif
#ifndef INCLUDED_Std
#include <Std.h>
#endif
#ifndef INCLUDED_expresso_MasterCollector
#include <expresso/MasterCollector.h>
#endif
#ifndef INCLUDED_expresso_Options
#include <expresso/Options.h>
#endif
#ifndef INCLUDED_haxe_macro_ExprDef
#include <haxe/macro/ExprDef.h>
#endif
namespace expresso{

Void MasterCollector_obj::__construct()
{
HX_STACK_FRAME("expresso.MasterCollector","new",0xbe1158ee,"expresso.MasterCollector.new","expresso/MasterCollector.hx",19,0xa8eab283)
HX_STACK_THIS(this)
{
	HX_STACK_LINE(22)
	this->compilerString = HX_HCSTRING("","\x00","\x00","\x00","\x00");
	HX_STACK_LINE(203)
	this->unhandledExpressions = Dynamic( Array_obj<Dynamic>::__new() );
	HX_STACK_LINE(204)
	::expresso::Options tmp = ::expresso::Options_obj::__new();		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(204)
	this->globalOptions = tmp;
	HX_STACK_LINE(206)
	this->classPaths = Array_obj< ::String >::__new();
	HX_STACK_LINE(207)
	this->classPathsEReg = Array_obj< ::Dynamic >::__new();
	HX_STACK_LINE(208)
	this->positionsEreg = Array_obj< ::Dynamic >::__new();
	HX_STACK_LINE(210)
	Dynamic tmp1 = this->resetPosition();		HX_STACK_VAR(tmp1,"tmp1");
	HX_STACK_LINE(210)
	this->set_positionInfo(tmp1);
}
;
	return null();
}

//MasterCollector_obj::~MasterCollector_obj() { }

Dynamic MasterCollector_obj::__CreateEmpty() { return  new MasterCollector_obj; }
hx::ObjectPtr< MasterCollector_obj > MasterCollector_obj::__new()
{  hx::ObjectPtr< MasterCollector_obj > _result_ = new MasterCollector_obj();
	_result_->__construct();
	return _result_;}

Dynamic MasterCollector_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< MasterCollector_obj > _result_ = new MasterCollector_obj();
	_result_->__construct();
	return _result_;}

::haxe::macro::ExprDef MasterCollector_obj::get_lastIdentifiedLandmark( ){
	HX_STACK_FRAME("expresso.MasterCollector","get_lastIdentifiedLandmark",0x16a685e4,"expresso.MasterCollector.get_lastIdentifiedLandmark","expresso/MasterCollector.hx",26,0xa8eab283)
	HX_STACK_THIS(this)
	HX_STACK_LINE(27)
	::haxe::macro::ExprDef tmp = this->lastIdentifiedLandmark;		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(27)
	return tmp;
}


HX_DEFINE_DYNAMIC_FUNC0(MasterCollector_obj,get_lastIdentifiedLandmark,return )

::haxe::macro::ExprDef MasterCollector_obj::set_lastIdentifiedLandmark( ::haxe::macro::ExprDef newLandmark){
	HX_STACK_FRAME("expresso.MasterCollector","set_lastIdentifiedLandmark",0x763b4c58,"expresso.MasterCollector.set_lastIdentifiedLandmark","expresso/MasterCollector.hx",31,0xa8eab283)
	HX_STACK_THIS(this)
	HX_STACK_ARG(newLandmark,"newLandmark")
	HX_STACK_LINE(32)
	this->lastIdentifiedLandmark = newLandmark;
	HX_STACK_LINE(34)
	::haxe::macro::ExprDef tmp = this->get_lastIdentifiedLandmark();		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(34)
	return tmp;
}


HX_DEFINE_DYNAMIC_FUNC1(MasterCollector_obj,set_lastIdentifiedLandmark,return )

Dynamic MasterCollector_obj::get_positionInfo( ){
	HX_STACK_FRAME("expresso.MasterCollector","get_positionInfo",0x3147b0f2,"expresso.MasterCollector.get_positionInfo","expresso/MasterCollector.hx",41,0xa8eab283)
	HX_STACK_THIS(this)
	HX_STACK_LINE(42)
	Dynamic tmp = this->positionInfo;		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(42)
	return tmp;
}


HX_DEFINE_DYNAMIC_FUNC0(MasterCollector_obj,get_positionInfo,return )

Dynamic MasterCollector_obj::set_positionInfo( Dynamic newPositionInfo){
	HX_STACK_FRAME("expresso.MasterCollector","set_positionInfo",0x87899e66,"expresso.MasterCollector.set_positionInfo","expresso/MasterCollector.hx",46,0xa8eab283)
	HX_STACK_THIS(this)
	HX_STACK_ARG(newPositionInfo,"newPositionInfo")
	HX_STACK_LINE(47)
	this->positionInfo = newPositionInfo;
	HX_STACK_LINE(48)
	Dynamic tmp = this->get_positionInfo();		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(48)
	return tmp;
}


HX_DEFINE_DYNAMIC_FUNC1(MasterCollector_obj,set_positionInfo,return )

::expresso::Options MasterCollector_obj::get_globalOptions( ){
	HX_STACK_FRAME("expresso.MasterCollector","get_globalOptions",0xcb959ca0,"expresso.MasterCollector.get_globalOptions","expresso/MasterCollector.hx",54,0xa8eab283)
	HX_STACK_THIS(this)
	HX_STACK_LINE(55)
	::expresso::Options tmp = this->globalOptions;		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(55)
	return tmp;
}


HX_DEFINE_DYNAMIC_FUNC0(MasterCollector_obj,get_globalOptions,return )

Array< ::String > MasterCollector_obj::get_classPaths( ){
	HX_STACK_FRAME("expresso.MasterCollector","get_classPaths",0xf2390651,"expresso.MasterCollector.get_classPaths","expresso/MasterCollector.hx",73,0xa8eab283)
	HX_STACK_THIS(this)
	HX_STACK_LINE(73)
	return this->classPaths;
}


HX_DEFINE_DYNAMIC_FUNC0(MasterCollector_obj,get_classPaths,return )

Array< ::Dynamic > MasterCollector_obj::get_classPathsEReg( ){
	HX_STACK_FRAME("expresso.MasterCollector","get_classPathsEReg",0x3b834ce0,"expresso.MasterCollector.get_classPathsEReg","expresso/MasterCollector.hx",140,0xa8eab283)
	HX_STACK_THIS(this)
	HX_STACK_LINE(140)
	return this->classPathsEReg;
}


HX_DEFINE_DYNAMIC_FUNC0(MasterCollector_obj,get_classPathsEReg,return )

Array< ::Dynamic > MasterCollector_obj::get_positionsEreg( ){
	HX_STACK_FRAME("expresso.MasterCollector","get_positionsEreg",0x0136d33e,"expresso.MasterCollector.get_positionsEreg","expresso/MasterCollector.hx",148,0xa8eab283)
	HX_STACK_THIS(this)
	HX_STACK_LINE(148)
	return this->positionsEreg;
}


HX_DEFINE_DYNAMIC_FUNC0(MasterCollector_obj,get_positionsEreg,return )

cpp::ArrayBase MasterCollector_obj::get_unhandledExpressions( ){
	HX_STACK_FRAME("expresso.MasterCollector","get_unhandledExpressions",0x75dee453,"expresso.MasterCollector.get_unhandledExpressions","expresso/MasterCollector.hx",158,0xa8eab283)
	HX_STACK_THIS(this)
	HX_STACK_LINE(158)
	return this->unhandledExpressions;
}


HX_DEFINE_DYNAMIC_FUNC0(MasterCollector_obj,get_unhandledExpressions,return )

Void MasterCollector_obj::storeUnhandledExpression( Dynamic item){
{
		HX_STACK_FRAME("expresso.MasterCollector","storeUnhandledExpression",0x48bedb4c,"expresso.MasterCollector.storeUnhandledExpression","expresso/MasterCollector.hx",217,0xa8eab283)
		HX_STACK_THIS(this)
		HX_STACK_ARG(item,"item")
		HX_STACK_LINE(218)
		int tmp = this->get_unhandledExpressions()->__Field(HX_HCSTRING("length","\xe6","\x94","\x07","\x9f"), hx::paccDynamic );		HX_STACK_VAR(tmp,"tmp");
		HX_STACK_LINE(218)
		Dynamic tmp1 = item;		HX_STACK_VAR(tmp1,"tmp1");
		HX_STACK_LINE(218)
		hx::IndexRef((this->get_unhandledExpressions()).mPtr,tmp) = tmp1;
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC1(MasterCollector_obj,storeUnhandledExpression,(void))

Dynamic MasterCollector_obj::resetPosition( ){
	HX_STACK_FRAME("expresso.MasterCollector","resetPosition",0xcbf093a6,"expresso.MasterCollector.resetPosition","expresso/MasterCollector.hx",222,0xa8eab283)
	HX_STACK_THIS(this)
	HX_STACK_LINE(225)
	::String tmp = HX_HCSTRING("","\x00","\x00","\x00","\x00");		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(226)
	::String tmp1 = HX_HCSTRING("","\x00","\x00","\x00","\x00");		HX_STACK_VAR(tmp1,"tmp1");
	HX_STACK_LINE(227)
	::String tmp2 = HX_HCSTRING("","\x00","\x00","\x00","\x00");		HX_STACK_VAR(tmp2,"tmp2");
	HX_STACK_LINE(228)
	::String tmp3 = HX_HCSTRING("","\x00","\x00","\x00","\x00");		HX_STACK_VAR(tmp3,"tmp3");
	HX_STACK_LINE(229)
	int tmp4 = (int)-1;		HX_STACK_VAR(tmp4,"tmp4");
	HX_STACK_LINE(230)
	int tmp5 = (int)-1;		HX_STACK_VAR(tmp5,"tmp5");
	HX_STACK_LINE(231)
	int tmp6 = (int)-1;		HX_STACK_VAR(tmp6,"tmp6");
	HX_STACK_LINE(232)
	::String tmp7 = HX_HCSTRING("","\x00","\x00","\x00","\x00");		HX_STACK_VAR(tmp7,"tmp7");
	struct _Function_1_1{
		inline static Dynamic Block( int &tmp5,int &tmp6,::String &tmp,int &tmp4,::String &tmp2,::String &tmp3,::String &tmp1,::String &tmp7){
			HX_STACK_FRAME("*","closure",0x5bdab937,"*.closure","expresso/MasterCollector.hx",224,0xa8eab283)
			{
				hx::Anon __result = hx::Anon_obj::Create();
				__result->Add(HX_HCSTRING("fieldName","\x25","\x18","\x4e","\xe0") , tmp,false);
				__result->Add(HX_HCSTRING("classPath","\xfd","\x05","\x90","\xdd") , tmp1,false);
				__result->Add(HX_HCSTRING("classPathAddition","\x19","\xf4","\x22","\x9f") , tmp2,false);
				__result->Add(HX_HCSTRING("className","\xa3","\x92","\x3d","\xdc") , tmp3,false);
				__result->Add(HX_HCSTRING("lineNumber","\xdd","\x81","\x22","\x76") , tmp4,false);
				__result->Add(HX_HCSTRING("lowerLimit","\x7a","\xb1","\x5f","\x31") , tmp5,false);
				__result->Add(HX_HCSTRING("upperLimit","\x79","\x32","\x8e","\x36") , tmp6,false);
				__result->Add(HX_HCSTRING("charactersOrLines","\x52","\x86","\xaa","\xe4") , tmp7,false);
				return __result;
			}
			return null();
		}
	};
	HX_STACK_LINE(224)
	Dynamic tmp8 = _Function_1_1::Block(tmp5,tmp6,tmp,tmp4,tmp2,tmp3,tmp1,tmp7);		HX_STACK_VAR(tmp8,"tmp8");
	HX_STACK_LINE(223)
	this->set_positionInfo(tmp8);
	HX_STACK_LINE(235)
	Dynamic tmp9 = this->get_positionInfo();		HX_STACK_VAR(tmp9,"tmp9");
	HX_STACK_LINE(235)
	return tmp9;
}


HX_DEFINE_DYNAMIC_FUNC0(MasterCollector_obj,resetPosition,return )

bool MasterCollector_obj::loadPositionToObj( Dynamic position,::String fieldName){
	HX_STACK_FRAME("expresso.MasterCollector","loadPositionToObj",0xa0be06db,"expresso.MasterCollector.loadPositionToObj","expresso/MasterCollector.hx",266,0xa8eab283)
	HX_STACK_THIS(this)
	HX_STACK_ARG(position,"position")
	HX_STACK_ARG(fieldName,"fieldName")
	HX_STACK_LINE(267)
	this->resetPosition();
	HX_STACK_LINE(269)
	bool tmp = (fieldName != null());		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(269)
	::String tmp1;		HX_STACK_VAR(tmp1,"tmp1");
	HX_STACK_LINE(269)
	if ((tmp)){
		HX_STACK_LINE(269)
		tmp1 = fieldName;
	}
	else{
		HX_STACK_LINE(269)
		tmp1 = HX_HCSTRING("","\x00","\x00","\x00","\x00");
	}
	HX_STACK_LINE(269)
	fieldName = tmp1;
	HX_STACK_LINE(271)
	Dynamic tmp2 = position;		HX_STACK_VAR(tmp2,"tmp2");
	HX_STACK_LINE(271)
	::String tmp3 = ::Std_obj::string(tmp2);		HX_STACK_VAR(tmp3,"tmp3");
	HX_STACK_LINE(271)
	::String currentPosString = tmp3;		HX_STACK_VAR(currentPosString,"currentPosString");
	HX_STACK_LINE(272)
	::EReg classPathRegEx;		HX_STACK_VAR(classPathRegEx,"classPathRegEx");
	HX_STACK_LINE(273)
	::EReg positionRegEx;		HX_STACK_VAR(positionRegEx,"positionRegEx");
	HX_STACK_LINE(275)
	{
		HX_STACK_LINE(275)
		int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
		HX_STACK_LINE(275)
		int tmp4 = this->get_classPathsEReg()->length;		HX_STACK_VAR(tmp4,"tmp4");
		HX_STACK_LINE(275)
		int _g = tmp4;		HX_STACK_VAR(_g,"_g");
		HX_STACK_LINE(275)
		while((true)){
			HX_STACK_LINE(275)
			bool tmp5 = (_g1 < _g);		HX_STACK_VAR(tmp5,"tmp5");
			HX_STACK_LINE(275)
			bool tmp6 = !(tmp5);		HX_STACK_VAR(tmp6,"tmp6");
			HX_STACK_LINE(275)
			if ((tmp6)){
				HX_STACK_LINE(275)
				break;
			}
			HX_STACK_LINE(275)
			int tmp7 = (_g1)++;		HX_STACK_VAR(tmp7,"tmp7");
			HX_STACK_LINE(275)
			int i = tmp7;		HX_STACK_VAR(i,"i");
			HX_STACK_LINE(277)
			::EReg tmp8 = this->get_classPathsEReg()->__get(i).StaticCast< ::EReg >();		HX_STACK_VAR(tmp8,"tmp8");
			HX_STACK_LINE(277)
			classPathRegEx = tmp8;
			HX_STACK_LINE(278)
			::EReg tmp9 = this->get_positionsEreg()->__get(i).StaticCast< ::EReg >();		HX_STACK_VAR(tmp9,"tmp9");
			HX_STACK_LINE(278)
			positionRegEx = tmp9;
			HX_STACK_LINE(280)
			::String tmp10 = currentPosString;		HX_STACK_VAR(tmp10,"tmp10");
			HX_STACK_LINE(280)
			bool tmp11 = classPathRegEx->match(tmp10);		HX_STACK_VAR(tmp11,"tmp11");
			HX_STACK_LINE(280)
			if ((tmp11)){
				HX_STACK_LINE(282)
				Dynamic tmp12 = this->get_positionInfo();		HX_STACK_VAR(tmp12,"tmp12");
				HX_STACK_LINE(282)
				tmp12->__FieldRef(HX_HCSTRING("fieldName","\x25","\x18","\x4e","\xe0")) = fieldName;
				HX_STACK_LINE(283)
				::String tmp13 = classPathRegEx->matched((int)1);		HX_STACK_VAR(tmp13,"tmp13");
				HX_STACK_LINE(283)
				Dynamic tmp14 = this->get_positionInfo();		HX_STACK_VAR(tmp14,"tmp14");
				HX_STACK_LINE(283)
				tmp14->__FieldRef(HX_HCSTRING("classPath","\xfd","\x05","\x90","\xdd")) = tmp13;
				HX_STACK_LINE(284)
				::String tmp15 = classPathRegEx->matched((int)2);		HX_STACK_VAR(tmp15,"tmp15");
				HX_STACK_LINE(284)
				Dynamic tmp16 = this->get_positionInfo();		HX_STACK_VAR(tmp16,"tmp16");
				HX_STACK_LINE(284)
				tmp16->__FieldRef(HX_HCSTRING("classPathAddition","\x19","\xf4","\x22","\x9f")) = tmp15;
				HX_STACK_LINE(285)
				::String tmp17 = classPathRegEx->matched((int)3);		HX_STACK_VAR(tmp17,"tmp17");
				HX_STACK_LINE(285)
				Dynamic tmp18 = this->get_positionInfo();		HX_STACK_VAR(tmp18,"tmp18");
				HX_STACK_LINE(285)
				tmp18->__FieldRef(HX_HCSTRING("className","\xa3","\x92","\x3d","\xdc")) = tmp17;
				HX_STACK_LINE(291)
				::String tmp19 = currentPosString;		HX_STACK_VAR(tmp19,"tmp19");
				HX_STACK_LINE(291)
				bool tmp20 = positionRegEx->match(tmp19);		HX_STACK_VAR(tmp20,"tmp20");
				HX_STACK_LINE(291)
				if ((tmp20)){
					HX_STACK_LINE(297)
					::String tmp21 = positionRegEx->matched((int)2);		HX_STACK_VAR(tmp21,"tmp21");
					HX_STACK_LINE(297)
					Dynamic tmp22 = ::Std_obj::parseInt(tmp21);		HX_STACK_VAR(tmp22,"tmp22");
					HX_STACK_LINE(297)
					Dynamic tmp23 = this->get_positionInfo();		HX_STACK_VAR(tmp23,"tmp23");
					HX_STACK_LINE(297)
					tmp23->__FieldRef(HX_HCSTRING("lineNumber","\xdd","\x81","\x22","\x76")) = tmp22;
					HX_STACK_LINE(298)
					::String tmp24 = positionRegEx->matched((int)6);		HX_STACK_VAR(tmp24,"tmp24");
					HX_STACK_LINE(298)
					Dynamic tmp25 = ::Std_obj::parseInt(tmp24);		HX_STACK_VAR(tmp25,"tmp25");
					HX_STACK_LINE(298)
					Dynamic tmp26 = this->get_positionInfo();		HX_STACK_VAR(tmp26,"tmp26");
					HX_STACK_LINE(298)
					tmp26->__FieldRef(HX_HCSTRING("lowerLimit","\x7a","\xb1","\x5f","\x31")) = tmp25;
					HX_STACK_LINE(299)
					::String tmp27 = positionRegEx->matched((int)8);		HX_STACK_VAR(tmp27,"tmp27");
					HX_STACK_LINE(299)
					Dynamic tmp28 = ::Std_obj::parseInt(tmp27);		HX_STACK_VAR(tmp28,"tmp28");
					HX_STACK_LINE(299)
					Dynamic tmp29 = this->get_positionInfo();		HX_STACK_VAR(tmp29,"tmp29");
					HX_STACK_LINE(299)
					tmp29->__FieldRef(HX_HCSTRING("upperLimit","\x79","\x32","\x8e","\x36")) = tmp28;
					HX_STACK_LINE(300)
					::String tmp30 = positionRegEx->matched((int)4);		HX_STACK_VAR(tmp30,"tmp30");
					HX_STACK_LINE(300)
					Dynamic tmp31 = this->get_positionInfo();		HX_STACK_VAR(tmp31,"tmp31");
					HX_STACK_LINE(300)
					tmp31->__FieldRef(HX_HCSTRING("charactersOrLines","\x52","\x86","\xaa","\xe4")) = tmp30;
				}
				HX_STACK_LINE(306)
				return true;
			}
		}
	}
	HX_STACK_LINE(312)
	return false;
}


HX_DEFINE_DYNAMIC_FUNC2(MasterCollector_obj,loadPositionToObj,return )

Void MasterCollector_obj::setGlobalOptions( Array< ::String > options){
{
		HX_STACK_FRAME("expresso.MasterCollector","setGlobalOptions",0x872bb9eb,"expresso.MasterCollector.setGlobalOptions","expresso/MasterCollector.hx",59,0xa8eab283)
		HX_STACK_ARG(options,"options")
		HX_STACK_LINE(60)
		::expresso::MasterCollector tmp = ::expresso::MasterCollector_obj::get_instance();		HX_STACK_VAR(tmp,"tmp");
		HX_STACK_LINE(60)
		::expresso::MasterCollector masterCollector = tmp;		HX_STACK_VAR(masterCollector,"masterCollector");
		HX_STACK_LINE(63)
		::expresso::Options tmp1 = masterCollector->get_globalOptions();		HX_STACK_VAR(tmp1,"tmp1");
		HX_STACK_LINE(63)
		tmp1->setOptions(options);
	}
return null();
}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(MasterCollector_obj,setGlobalOptions,(void))

Void MasterCollector_obj::setClassPaths( Array< ::String > newClassPaths){
{
		HX_STACK_FRAME("expresso.MasterCollector","setClassPaths",0x72447c26,"expresso.MasterCollector.setClassPaths","expresso/MasterCollector.hx",77,0xa8eab283)
		HX_STACK_ARG(newClassPaths,"newClassPaths")
		HX_STACK_LINE(78)
		::expresso::MasterCollector tmp = ::expresso::MasterCollector_obj::get_instance();		HX_STACK_VAR(tmp,"tmp");
		HX_STACK_LINE(78)
		::expresso::MasterCollector masterCollector = tmp;		HX_STACK_VAR(masterCollector,"masterCollector");
		HX_STACK_LINE(83)
		{
			HX_STACK_LINE(83)
			int _g1 = (int)0;		HX_STACK_VAR(_g1,"_g1");
			HX_STACK_LINE(83)
			int _g = newClassPaths->length;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(83)
			while((true)){
				HX_STACK_LINE(83)
				bool tmp1 = (_g1 < _g);		HX_STACK_VAR(tmp1,"tmp1");
				HX_STACK_LINE(83)
				bool tmp2 = !(tmp1);		HX_STACK_VAR(tmp2,"tmp2");
				HX_STACK_LINE(83)
				if ((tmp2)){
					HX_STACK_LINE(83)
					break;
				}
				HX_STACK_LINE(83)
				int tmp3 = (_g1)++;		HX_STACK_VAR(tmp3,"tmp3");
				HX_STACK_LINE(83)
				int i = tmp3;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(85)
				::String tmp4 = newClassPaths->__get(i);		HX_STACK_VAR(tmp4,"tmp4");
				HX_STACK_LINE(85)
				::String classPath = tmp4;		HX_STACK_VAR(classPath,"classPath");
				HX_STACK_LINE(92)
				::EReg tmp5 = ::EReg_obj::__new(HX_HCSTRING("\\.","\x52","\x50","\x00","\x00"),HX_HCSTRING("g","\x67","\x00","\x00","\x00"));		HX_STACK_VAR(tmp5,"tmp5");
				HX_STACK_LINE(92)
				::EReg dotReplacingEReg = tmp5;		HX_STACK_VAR(dotReplacingEReg,"dotReplacingEReg");
				HX_STACK_LINE(94)
				::EReg tmp6 = ::EReg_obj::__new(HX_HCSTRING("([a-zA-Z0-9])*(/$)","\x61","\x2c","\x0d","\x17"),HX_HCSTRING("","\x00","\x00","\x00","\x00"));		HX_STACK_VAR(tmp6,"tmp6");
				HX_STACK_LINE(94)
				::EReg finishingEReg = tmp6;		HX_STACK_VAR(finishingEReg,"finishingEReg");
				HX_STACK_LINE(98)
				::String tmp7 = classPath;		HX_STACK_VAR(tmp7,"tmp7");
				HX_STACK_LINE(98)
				bool tmp8 = dotReplacingEReg->match(tmp7);		HX_STACK_VAR(tmp8,"tmp8");
				HX_STACK_LINE(98)
				if ((tmp8)){
					HX_STACK_LINE(101)
					::String tmp9 = classPath;		HX_STACK_VAR(tmp9,"tmp9");
					HX_STACK_LINE(101)
					::String tmp10 = dotReplacingEReg->replace(tmp9,HX_HCSTRING("/","\x2f","\x00","\x00","\x00"));		HX_STACK_VAR(tmp10,"tmp10");
					HX_STACK_LINE(101)
					classPath = tmp10;
				}
				HX_STACK_LINE(105)
				::String tmp9 = classPath;		HX_STACK_VAR(tmp9,"tmp9");
				HX_STACK_LINE(105)
				bool tmp10 = finishingEReg->match(tmp9);		HX_STACK_VAR(tmp10,"tmp10");
				HX_STACK_LINE(105)
				bool tmp11 = !(tmp10);		HX_STACK_VAR(tmp11,"tmp11");
				HX_STACK_LINE(105)
				if ((tmp11)){
					HX_STACK_LINE(106)
					hx::AddEq(classPath,HX_HCSTRING("/","\x2f","\x00","\x00","\x00"));
				}
				HX_STACK_LINE(111)
				::String tmp12 = (HX_HCSTRING("(","\x28","\x00","\x00","\x00") + classPath);		HX_STACK_VAR(tmp12,"tmp12");
				HX_STACK_LINE(111)
				::String tmp13 = (tmp12 + HX_HCSTRING(")([a-zA-Z0-9/?]*)([a-zA-Z0-9]*\\.hx)(:?)([0-9]*)([: ]?)(characters|lines)( ?)([0-9]*)(-?)([0-9]*)","\xcd","\x29","\xb2","\x4c"));		HX_STACK_VAR(tmp13,"tmp13");
				HX_STACK_LINE(111)
				::String clPathclPathEregString = tmp13;		HX_STACK_VAR(clPathclPathEregString,"clPathclPathEregString");
				HX_STACK_LINE(115)
				::String tmp14 = (HX_HCSTRING("(","\x28","\x00","\x00","\x00") + classPath);		HX_STACK_VAR(tmp14,"tmp14");
				HX_STACK_LINE(115)
				::String tmp15 = (tmp14 + HX_HCSTRING(")([a-zA-Z0-9/?]*)([a-zA-Z0-9]*\\.hx)","\x7d","\xcd","\x31","\xaf"));		HX_STACK_VAR(tmp15,"tmp15");
				HX_STACK_LINE(115)
				::String clPathEregString = tmp15;		HX_STACK_VAR(clPathEregString,"clPathEregString");
				HX_STACK_LINE(119)
				::String posEregString = HX_HCSTRING("(\\.hx:)([0-9]*)(:? ?)(characters|lines)( ?)([0-9]*)(-?)([0-9]*)","\xf4","\xa7","\xb6","\x48");		HX_STACK_VAR(posEregString,"posEregString");
				HX_STACK_LINE(124)
				::String tmp16 = classPath;		HX_STACK_VAR(tmp16,"tmp16");
				HX_STACK_LINE(124)
				masterCollector->get_classPaths()[i] = tmp16;
				HX_STACK_LINE(127)
				::EReg tmp17 = ::EReg_obj::__new(clPathEregString,HX_HCSTRING("","\x00","\x00","\x00","\x00"));		HX_STACK_VAR(tmp17,"tmp17");
				HX_STACK_LINE(127)
				masterCollector->get_classPathsEReg()[i] = tmp17;
				HX_STACK_LINE(129)
				::EReg tmp18 = ::EReg_obj::__new(posEregString,HX_HCSTRING("","\x00","\x00","\x00","\x00"));		HX_STACK_VAR(tmp18,"tmp18");
				HX_STACK_LINE(129)
				masterCollector->get_positionsEreg()[i] = tmp18;
			}
		}
	}
return null();
}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(MasterCollector_obj,setClassPaths,(void))

::expresso::MasterCollector MasterCollector_obj::_INSTANCE;

::expresso::MasterCollector MasterCollector_obj::get_instance( ){
	HX_STACK_FRAME("expresso.MasterCollector","get_instance",0x6a9ac950,"expresso.MasterCollector.get_instance","expresso/MasterCollector.hx",195,0xa8eab283)
	HX_STACK_LINE(196)
	::expresso::MasterCollector tmp = ::expresso::MasterCollector_obj::_INSTANCE;		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(196)
	bool tmp1 = (tmp != null());		HX_STACK_VAR(tmp1,"tmp1");
	HX_STACK_LINE(196)
	::expresso::MasterCollector tmp2;		HX_STACK_VAR(tmp2,"tmp2");
	HX_STACK_LINE(196)
	if ((tmp1)){
		HX_STACK_LINE(197)
		tmp2 = ::expresso::MasterCollector_obj::_INSTANCE;
	}
	else{
		HX_STACK_LINE(198)
		::expresso::MasterCollector tmp3 = ::expresso::MasterCollector_obj::__new();		HX_STACK_VAR(tmp3,"tmp3");
		HX_STACK_LINE(198)
		tmp2 = ::expresso::MasterCollector_obj::_INSTANCE = tmp3;
	}
	HX_STACK_LINE(196)
	return tmp2;
}


STATIC_HX_DEFINE_DYNAMIC_FUNC0(MasterCollector_obj,get_instance,return )


MasterCollector_obj::MasterCollector_obj()
{
}

void MasterCollector_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(MasterCollector);
	HX_MARK_MEMBER_NAME(compilerString,"compilerString");
	HX_MARK_MEMBER_NAME(lastIdentifiedLandmark,"lastIdentifiedLandmark");
	HX_MARK_MEMBER_NAME(positionInfo,"positionInfo");
	HX_MARK_MEMBER_NAME(globalOptions,"globalOptions");
	HX_MARK_MEMBER_NAME(classPaths,"classPaths");
	HX_MARK_MEMBER_NAME(classPathsEReg,"classPathsEReg");
	HX_MARK_MEMBER_NAME(positionsEreg,"positionsEreg");
	HX_MARK_MEMBER_NAME(unhandledExpressions,"unhandledExpressions");
	HX_MARK_END_CLASS();
}

void MasterCollector_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(compilerString,"compilerString");
	HX_VISIT_MEMBER_NAME(lastIdentifiedLandmark,"lastIdentifiedLandmark");
	HX_VISIT_MEMBER_NAME(positionInfo,"positionInfo");
	HX_VISIT_MEMBER_NAME(globalOptions,"globalOptions");
	HX_VISIT_MEMBER_NAME(classPaths,"classPaths");
	HX_VISIT_MEMBER_NAME(classPathsEReg,"classPathsEReg");
	HX_VISIT_MEMBER_NAME(positionsEreg,"positionsEreg");
	HX_VISIT_MEMBER_NAME(unhandledExpressions,"unhandledExpressions");
}

Dynamic MasterCollector_obj::__Field(const ::String &inName,hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 10:
		if (HX_FIELD_EQ(inName,"classPaths") ) { return inCallProp == hx::paccAlways ? get_classPaths() : classPaths; }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"positionInfo") ) { return inCallProp == hx::paccAlways ? get_positionInfo() : positionInfo; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"globalOptions") ) { return inCallProp == hx::paccAlways ? get_globalOptions() : globalOptions; }
		if (HX_FIELD_EQ(inName,"positionsEreg") ) { return inCallProp == hx::paccAlways ? get_positionsEreg() : positionsEreg; }
		if (HX_FIELD_EQ(inName,"resetPosition") ) { return resetPosition_dyn(); }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"compilerString") ) { return compilerString; }
		if (HX_FIELD_EQ(inName,"get_classPaths") ) { return get_classPaths_dyn(); }
		if (HX_FIELD_EQ(inName,"classPathsEReg") ) { return inCallProp == hx::paccAlways ? get_classPathsEReg() : classPathsEReg; }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"get_positionInfo") ) { return get_positionInfo_dyn(); }
		if (HX_FIELD_EQ(inName,"set_positionInfo") ) { return set_positionInfo_dyn(); }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"get_globalOptions") ) { return get_globalOptions_dyn(); }
		if (HX_FIELD_EQ(inName,"get_positionsEreg") ) { return get_positionsEreg_dyn(); }
		if (HX_FIELD_EQ(inName,"loadPositionToObj") ) { return loadPositionToObj_dyn(); }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"get_classPathsEReg") ) { return get_classPathsEReg_dyn(); }
		break;
	case 20:
		if (HX_FIELD_EQ(inName,"unhandledExpressions") ) { return inCallProp == hx::paccAlways ? get_unhandledExpressions() : unhandledExpressions; }
		break;
	case 22:
		if (HX_FIELD_EQ(inName,"lastIdentifiedLandmark") ) { return inCallProp == hx::paccAlways ? get_lastIdentifiedLandmark() : lastIdentifiedLandmark; }
		break;
	case 24:
		if (HX_FIELD_EQ(inName,"get_unhandledExpressions") ) { return get_unhandledExpressions_dyn(); }
		if (HX_FIELD_EQ(inName,"storeUnhandledExpression") ) { return storeUnhandledExpression_dyn(); }
		break;
	case 26:
		if (HX_FIELD_EQ(inName,"get_lastIdentifiedLandmark") ) { return get_lastIdentifiedLandmark_dyn(); }
		if (HX_FIELD_EQ(inName,"set_lastIdentifiedLandmark") ) { return set_lastIdentifiedLandmark_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

bool MasterCollector_obj::__GetStatic(const ::String &inName, Dynamic &outValue, hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 9:
		if (HX_FIELD_EQ(inName,"_INSTANCE") ) { outValue = _INSTANCE; return true;  }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"get_instance") ) { outValue = get_instance_dyn(); return true;  }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"setClassPaths") ) { outValue = setClassPaths_dyn(); return true;  }
		break;
	case 16:
		if (HX_FIELD_EQ(inName,"setGlobalOptions") ) { outValue = setGlobalOptions_dyn(); return true;  }
	}
	return false;
}

Dynamic MasterCollector_obj::__SetField(const ::String &inName,const Dynamic &inValue,hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 10:
		if (HX_FIELD_EQ(inName,"classPaths") ) { classPaths=inValue.Cast< Array< ::String > >(); return inValue; }
		break;
	case 12:
		if (HX_FIELD_EQ(inName,"positionInfo") ) { if (inCallProp == hx::paccAlways) return set_positionInfo(inValue);positionInfo=inValue.Cast< Dynamic >(); return inValue; }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"globalOptions") ) { globalOptions=inValue.Cast< ::expresso::Options >(); return inValue; }
		if (HX_FIELD_EQ(inName,"positionsEreg") ) { positionsEreg=inValue.Cast< Array< ::Dynamic > >(); return inValue; }
		break;
	case 14:
		if (HX_FIELD_EQ(inName,"compilerString") ) { compilerString=inValue.Cast< ::String >(); return inValue; }
		if (HX_FIELD_EQ(inName,"classPathsEReg") ) { classPathsEReg=inValue.Cast< Array< ::Dynamic > >(); return inValue; }
		break;
	case 20:
		if (HX_FIELD_EQ(inName,"unhandledExpressions") ) { unhandledExpressions=inValue.Cast< cpp::ArrayBase >(); return inValue; }
		break;
	case 22:
		if (HX_FIELD_EQ(inName,"lastIdentifiedLandmark") ) { if (inCallProp == hx::paccAlways) return set_lastIdentifiedLandmark(inValue);lastIdentifiedLandmark=inValue.Cast< ::haxe::macro::ExprDef >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

bool MasterCollector_obj::__SetStatic(const ::String &inName,Dynamic &ioValue,hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 9:
		if (HX_FIELD_EQ(inName,"_INSTANCE") ) { _INSTANCE=ioValue.Cast< ::expresso::MasterCollector >(); return true; }
	}
	return false;
}

void MasterCollector_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_HCSTRING("compilerString","\xd0","\x3d","\xec","\x1e"));
	outFields->push(HX_HCSTRING("lastIdentifiedLandmark","\xe9","\x6a","\xe9","\xa3"));
	outFields->push(HX_HCSTRING("positionInfo","\xb7","\x0d","\x17","\x6c"));
	outFields->push(HX_HCSTRING("globalOptions","\x3b","\x6c","\x37","\x06"));
	outFields->push(HX_HCSTRING("classPaths","\xd6","\x37","\x75","\x00"));
	outFields->push(HX_HCSTRING("classPathsEReg","\xe5","\x24","\x77","\x4e"));
	outFields->push(HX_HCSTRING("positionsEreg","\xd9","\xa2","\xd8","\x3b"));
	outFields->push(HX_HCSTRING("unhandledExpressions","\x18","\x0e","\x30","\xad"));
	super::__GetFields(outFields);
};

#if HXCPP_SCRIPTABLE
static hx::StorageInfo sMemberStorageInfo[] = {
	{hx::fsString,(int)offsetof(MasterCollector_obj,compilerString),HX_HCSTRING("compilerString","\xd0","\x3d","\xec","\x1e")},
	{hx::fsObject /*::haxe::macro::ExprDef*/ ,(int)offsetof(MasterCollector_obj,lastIdentifiedLandmark),HX_HCSTRING("lastIdentifiedLandmark","\xe9","\x6a","\xe9","\xa3")},
	{hx::fsObject /*Dynamic*/ ,(int)offsetof(MasterCollector_obj,positionInfo),HX_HCSTRING("positionInfo","\xb7","\x0d","\x17","\x6c")},
	{hx::fsObject /*::expresso::Options*/ ,(int)offsetof(MasterCollector_obj,globalOptions),HX_HCSTRING("globalOptions","\x3b","\x6c","\x37","\x06")},
	{hx::fsObject /*Array< ::String >*/ ,(int)offsetof(MasterCollector_obj,classPaths),HX_HCSTRING("classPaths","\xd6","\x37","\x75","\x00")},
	{hx::fsObject /*Array< ::Dynamic >*/ ,(int)offsetof(MasterCollector_obj,classPathsEReg),HX_HCSTRING("classPathsEReg","\xe5","\x24","\x77","\x4e")},
	{hx::fsObject /*Array< ::Dynamic >*/ ,(int)offsetof(MasterCollector_obj,positionsEreg),HX_HCSTRING("positionsEreg","\xd9","\xa2","\xd8","\x3b")},
	{hx::fsObject /*cpp::ArrayBase*/ ,(int)offsetof(MasterCollector_obj,unhandledExpressions),HX_HCSTRING("unhandledExpressions","\x18","\x0e","\x30","\xad")},
	{ hx::fsUnknown, 0, null()}
};
static hx::StaticInfo sStaticStorageInfo[] = {
	{hx::fsObject /*::expresso::MasterCollector*/ ,(void *) &MasterCollector_obj::_INSTANCE,HX_HCSTRING("_INSTANCE","\xf4","\xa6","\xfc","\xfa")},
	{ hx::fsUnknown, 0, null()}
};
#endif

static ::String sMemberFields[] = {
	HX_HCSTRING("compilerString","\xd0","\x3d","\xec","\x1e"),
	HX_HCSTRING("lastIdentifiedLandmark","\xe9","\x6a","\xe9","\xa3"),
	HX_HCSTRING("get_lastIdentifiedLandmark","\xb2","\xbc","\xee","\xdb"),
	HX_HCSTRING("set_lastIdentifiedLandmark","\x26","\x83","\x83","\x3b"),
	HX_HCSTRING("positionInfo","\xb7","\x0d","\x17","\x6c"),
	HX_HCSTRING("get_positionInfo","\x40","\xfa","\xb5","\x70"),
	HX_HCSTRING("set_positionInfo","\xb4","\xe7","\xf7","\xc6"),
	HX_HCSTRING("globalOptions","\x3b","\x6c","\x37","\x06"),
	HX_HCSTRING("get_globalOptions","\x92","\x77","\xa7","\x0c"),
	HX_HCSTRING("classPaths","\xd6","\x37","\x75","\x00"),
	HX_HCSTRING("get_classPaths","\x1f","\xc0","\x6a","\x76"),
	HX_HCSTRING("classPathsEReg","\xe5","\x24","\x77","\x4e"),
	HX_HCSTRING("get_classPathsEReg","\xae","\x05","\x11","\xea"),
	HX_HCSTRING("positionsEreg","\xd9","\xa2","\xd8","\x3b"),
	HX_HCSTRING("get_positionsEreg","\x30","\xae","\x48","\x42"),
	HX_HCSTRING("unhandledExpressions","\x18","\x0e","\x30","\xad"),
	HX_HCSTRING("get_unhandledExpressions","\xa1","\x2b","\xcc","\xef"),
	HX_HCSTRING("storeUnhandledExpression","\x9a","\x22","\xac","\xc2"),
	HX_HCSTRING("resetPosition","\x98","\x8d","\x99","\xfb"),
	HX_HCSTRING("loadPositionToObj","\xcd","\xe1","\xcf","\xe1"),
	::String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(MasterCollector_obj::__mClass,"__mClass");
	HX_MARK_MEMBER_NAME(MasterCollector_obj::_INSTANCE,"_INSTANCE");
};

#ifdef HXCPP_VISIT_ALLOCS
static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(MasterCollector_obj::__mClass,"__mClass");
	HX_VISIT_MEMBER_NAME(MasterCollector_obj::_INSTANCE,"_INSTANCE");
};

#endif

hx::Class MasterCollector_obj::__mClass;

static ::String sStaticFields[] = {
	HX_HCSTRING("setGlobalOptions","\x39","\x03","\x9a","\xc6"),
	HX_HCSTRING("setClassPaths","\x18","\x76","\xed","\xa1"),
	HX_HCSTRING("_INSTANCE","\xf4","\xa6","\xfc","\xfa"),
	HX_HCSTRING("get_instance","\x9e","\xd3","\xfa","\x0e"),
	::String(null()) };

void MasterCollector_obj::__register()
{
	hx::Static(__mClass) = new hx::Class_obj();
	__mClass->mName = HX_HCSTRING("expresso.MasterCollector","\xfc","\x09","\xa3","\xdd");
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &MasterCollector_obj::__GetStatic;
	__mClass->mSetStaticField = &MasterCollector_obj::__SetStatic;
	__mClass->mMarkFunc = sMarkStatics;
	__mClass->mStatics = hx::Class_obj::dupFunctions(sStaticFields);
	__mClass->mMembers = hx::Class_obj::dupFunctions(sMemberFields);
	__mClass->mCanCast = hx::TCanCast< MasterCollector_obj >;
#ifdef HXCPP_VISIT_ALLOCS
	__mClass->mVisitFunc = sVisitStatics;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = sStaticStorageInfo;
#endif
	hx::RegisterClass(__mClass->mName, __mClass);
}

} // end namespace expresso
