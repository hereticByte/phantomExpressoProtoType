#include <hxcpp.h>

#ifndef INCLUDED_haxe_Log
#include <haxe/Log.h>
#endif
#ifndef INCLUDED_tryOut_TryOut
#include <tryOut/TryOut.h>
#endif
namespace tryOut{

Void TryOut_obj::__construct(int _int,Float _float,::String string)
{
HX_STACK_FRAME("tryOut.TryOut","new",0xf2e6d320,"tryOut.TryOut.new","tryOut/TryOut.hx",10,0x7b5a682f)
HX_STACK_THIS(this)
HX_STACK_ARG(_int,"int")
HX_STACK_ARG(_float,"float")
HX_STACK_ARG(string,"string")
{
	HX_STACK_LINE(11)
	this->_int = _int;
	HX_STACK_LINE(12)
	this->_float = _float;
	HX_STACK_LINE(13)
	this->string = string;
}
;
	return null();
}

//TryOut_obj::~TryOut_obj() { }

Dynamic TryOut_obj::__CreateEmpty() { return  new TryOut_obj; }
hx::ObjectPtr< TryOut_obj > TryOut_obj::__new(int _int,Float _float,::String string)
{  hx::ObjectPtr< TryOut_obj > _result_ = new TryOut_obj();
	_result_->__construct(_int,_float,string);
	return _result_;}

Dynamic TryOut_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< TryOut_obj > _result_ = new TryOut_obj();
	_result_->__construct(inArgs[0],inArgs[1],inArgs[2]);
	return _result_;}

int TryOut_obj::doubleCurrentInteger( ){
	HX_STACK_FRAME("tryOut.TryOut","doubleCurrentInteger",0xe279b2b6,"tryOut.TryOut.doubleCurrentInteger","tryOut/TryOut.hx",17,0x7b5a682f)
	HX_STACK_THIS(this)
	HX_STACK_LINE(18)
	hx::MultEq(this->_int,(int)2);
	HX_STACK_LINE(19)
	int tmp = this->_int;		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(19)
	return tmp;
}


HX_DEFINE_DYNAMIC_FUNC0(TryOut_obj,doubleCurrentInteger,return )

Float TryOut_obj::multiplyTwoFloats( Float float01,Float float02){
	HX_STACK_FRAME("tryOut.TryOut","multiplyTwoFloats",0xa96ca1ff,"tryOut.TryOut.multiplyTwoFloats","tryOut/TryOut.hx",23,0x7b5a682f)
	HX_STACK_THIS(this)
	HX_STACK_ARG(float01,"float01")
	HX_STACK_ARG(float02,"float02")
	HX_STACK_LINE(24)
	Float tmp = (float01 * float02);		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(24)
	return tmp;
}


HX_DEFINE_DYNAMIC_FUNC2(TryOut_obj,multiplyTwoFloats,return )

Void TryOut_obj::tollFn( ){
{
		HX_STACK_FRAME("tryOut.TryOut","tollFn",0x0f38b023,"tryOut.TryOut.tollFn","tryOut/TryOut.hx",29,0x7b5a682f)
		HX_STACK_LINE(30)
		Dynamic tmp = hx::SourceInfo(HX_HCSTRING("TryOut.hx","\x6b","\xca","\x35","\x98"),30,HX_HCSTRING("tryOut.TryOut","\x2e","\x03","\x7f","\x78"),HX_HCSTRING("tollFn","\xe3","\x7a","\x95","\x92"));		HX_STACK_VAR(tmp,"tmp");
		HX_STACK_LINE(30)
		::haxe::Log_obj::trace(HX_HCSTRING("Toll!","\xe6","\xba","\x59","\xa7"),tmp);
	}
return null();
}


STATIC_HX_DEFINE_DYNAMIC_FUNC0(TryOut_obj,tollFn,(void))

Void TryOut_obj::executeVoidFn( Dynamic voidFn){
{
		HX_STACK_FRAME("tryOut.TryOut","executeVoidFn",0x443b0491,"tryOut.TryOut.executeVoidFn","tryOut/TryOut.hx",35,0x7b5a682f)
		HX_STACK_ARG(voidFn,"voidFn")
		HX_STACK_LINE(35)
		voidFn().Cast< Void >();
	}
return null();
}


STATIC_HX_DEFINE_DYNAMIC_FUNC1(TryOut_obj,executeVoidFn,(void))


TryOut_obj::TryOut_obj()
{
}

void TryOut_obj::__Mark(HX_MARK_PARAMS)
{
	HX_MARK_BEGIN_CLASS(TryOut);
	HX_MARK_MEMBER_NAME(_int,"int");
	HX_MARK_MEMBER_NAME(_float,"float");
	HX_MARK_MEMBER_NAME(string,"string");
	HX_MARK_END_CLASS();
}

void TryOut_obj::__Visit(HX_VISIT_PARAMS)
{
	HX_VISIT_MEMBER_NAME(_int,"int");
	HX_VISIT_MEMBER_NAME(_float,"float");
	HX_VISIT_MEMBER_NAME(string,"string");
}

Dynamic TryOut_obj::__Field(const ::String &inName,hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 3:
		if (HX_FIELD_EQ(inName,"int") ) { return _int; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"float") ) { return _float; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"string") ) { return string; }
		break;
	case 17:
		if (HX_FIELD_EQ(inName,"multiplyTwoFloats") ) { return multiplyTwoFloats_dyn(); }
		break;
	case 20:
		if (HX_FIELD_EQ(inName,"doubleCurrentInteger") ) { return doubleCurrentInteger_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

bool TryOut_obj::__GetStatic(const ::String &inName, Dynamic &outValue, hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 6:
		if (HX_FIELD_EQ(inName,"tollFn") ) { outValue = tollFn_dyn(); return true;  }
		break;
	case 13:
		if (HX_FIELD_EQ(inName,"executeVoidFn") ) { outValue = executeVoidFn_dyn(); return true;  }
	}
	return false;
}

Dynamic TryOut_obj::__SetField(const ::String &inName,const Dynamic &inValue,hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 3:
		if (HX_FIELD_EQ(inName,"int") ) { _int=inValue.Cast< int >(); return inValue; }
		break;
	case 5:
		if (HX_FIELD_EQ(inName,"float") ) { _float=inValue.Cast< Float >(); return inValue; }
		break;
	case 6:
		if (HX_FIELD_EQ(inName,"string") ) { string=inValue.Cast< ::String >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

bool TryOut_obj::__SetStatic(const ::String &inName,Dynamic &ioValue,hx::PropertyAccess inCallProp)
{
	return false;
}

void TryOut_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_HCSTRING("int","\xef","\x0c","\x50","\x00"));
	outFields->push(HX_HCSTRING("float","\x9c","\xc5","\x96","\x02"));
	outFields->push(HX_HCSTRING("string","\xd1","\x28","\x30","\x11"));
	super::__GetFields(outFields);
};

#if HXCPP_SCRIPTABLE
static hx::StorageInfo sMemberStorageInfo[] = {
	{hx::fsInt,(int)offsetof(TryOut_obj,_int),HX_HCSTRING("int","\xef","\x0c","\x50","\x00")},
	{hx::fsFloat,(int)offsetof(TryOut_obj,_float),HX_HCSTRING("float","\x9c","\xc5","\x96","\x02")},
	{hx::fsString,(int)offsetof(TryOut_obj,string),HX_HCSTRING("string","\xd1","\x28","\x30","\x11")},
	{ hx::fsUnknown, 0, null()}
};
static hx::StaticInfo *sStaticStorageInfo = 0;
#endif

static ::String sMemberFields[] = {
	HX_HCSTRING("int","\xef","\x0c","\x50","\x00"),
	HX_HCSTRING("float","\x9c","\xc5","\x96","\x02"),
	HX_HCSTRING("string","\xd1","\x28","\x30","\x11"),
	HX_HCSTRING("doubleCurrentInteger","\x76","\xcd","\x9b","\x57"),
	HX_HCSTRING("multiplyTwoFloats","\x3f","\x4f","\xa2","\xc7"),
	::String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(TryOut_obj::__mClass,"__mClass");
};

#ifdef HXCPP_VISIT_ALLOCS
static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(TryOut_obj::__mClass,"__mClass");
};

#endif

hx::Class TryOut_obj::__mClass;

static ::String sStaticFields[] = {
	HX_HCSTRING("tollFn","\xe3","\x7a","\x95","\x92"),
	HX_HCSTRING("executeVoidFn","\xd1","\x11","\x41","\xd8"),
	::String(null()) };

void TryOut_obj::__register()
{
	hx::Static(__mClass) = new hx::Class_obj();
	__mClass->mName = HX_HCSTRING("tryOut.TryOut","\x2e","\x03","\x7f","\x78");
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &TryOut_obj::__GetStatic;
	__mClass->mSetStaticField = &TryOut_obj::__SetStatic;
	__mClass->mMarkFunc = sMarkStatics;
	__mClass->mStatics = hx::Class_obj::dupFunctions(sStaticFields);
	__mClass->mMembers = hx::Class_obj::dupFunctions(sMemberFields);
	__mClass->mCanCast = hx::TCanCast< TryOut_obj >;
#ifdef HXCPP_VISIT_ALLOCS
	__mClass->mVisitFunc = sVisitStatics;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = sStaticStorageInfo;
#endif
	hx::RegisterClass(__mClass->mName, __mClass);
}

} // end namespace tryOut
