#include <hxcpp.h>

#ifndef INCLUDED_tryOut_packageLevel02_packageLevel03_DeeplyRootedClass
#include <tryOut/packageLevel02/packageLevel03/DeeplyRootedClass.h>
#endif
namespace tryOut{
namespace packageLevel02{
namespace packageLevel03{

Void DeeplyRootedClass_obj::__construct(int fantastisch,int toll,Dynamic optional)
{
HX_STACK_FRAME("tryOut.packageLevel02.packageLevel03.DeeplyRootedClass","new",0x9453e136,"tryOut.packageLevel02.packageLevel03.DeeplyRootedClass.new","tryOut/packageLevel02/packageLevel03/DeeplyRootedClass.hx",12,0x4549e85b)
HX_STACK_THIS(this)
HX_STACK_ARG(fantastisch,"fantastisch")
HX_STACK_ARG(toll,"toll")
HX_STACK_ARG(optional,"optional")
{
	HX_STACK_LINE(13)
	this->fantastisch = fantastisch;
	HX_STACK_LINE(14)
	this->toll = toll;
	HX_STACK_LINE(16)
	bool tmp = (optional != null());		HX_STACK_VAR(tmp,"tmp");
	HX_STACK_LINE(16)
	bool tmp1;		HX_STACK_VAR(tmp1,"tmp1");
	HX_STACK_LINE(16)
	if ((tmp)){
		HX_STACK_LINE(16)
		tmp1 = optional;
	}
	else{
		HX_STACK_LINE(16)
		tmp1 = false;
	}
	HX_STACK_LINE(16)
	this->optional = tmp1;
}
;
	return null();
}

//DeeplyRootedClass_obj::~DeeplyRootedClass_obj() { }

Dynamic DeeplyRootedClass_obj::__CreateEmpty() { return  new DeeplyRootedClass_obj; }
hx::ObjectPtr< DeeplyRootedClass_obj > DeeplyRootedClass_obj::__new(int fantastisch,int toll,Dynamic optional)
{  hx::ObjectPtr< DeeplyRootedClass_obj > _result_ = new DeeplyRootedClass_obj();
	_result_->__construct(fantastisch,toll,optional);
	return _result_;}

Dynamic DeeplyRootedClass_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< DeeplyRootedClass_obj > _result_ = new DeeplyRootedClass_obj();
	_result_->__construct(inArgs[0],inArgs[1],inArgs[2]);
	return _result_;}

Void DeeplyRootedClass_obj::deeplyRootedMethod( ){
{
		HX_STACK_FRAME("tryOut.packageLevel02.packageLevel03.DeeplyRootedClass","deeplyRootedMethod",0x19e81605,"tryOut.packageLevel02.packageLevel03.DeeplyRootedClass.deeplyRootedMethod","tryOut/packageLevel02/packageLevel03/DeeplyRootedClass.hx",22,0x4549e85b)
		HX_STACK_THIS(this)
		HX_STACK_LINE(23)
		int tmp = this->fantastisch;		HX_STACK_VAR(tmp,"tmp");
		HX_STACK_LINE(23)
		bool tmp1 = (tmp < (int)1000000);		HX_STACK_VAR(tmp1,"tmp1");
		HX_STACK_LINE(23)
		if ((tmp1)){
			HX_STACK_LINE(24)
			hx::MultEq(this->fantastisch,(int)2);
		}
		HX_STACK_LINE(26)
		int tmp2 = this->fantastisch;		HX_STACK_VAR(tmp2,"tmp2");
		HX_STACK_LINE(26)
		bool tmp3 = (tmp2 < (int)1000000);		HX_STACK_VAR(tmp3,"tmp3");
		HX_STACK_LINE(26)
		if ((tmp3)){
			HX_STACK_LINE(27)
			hx::MultEq(this->toll,(int)2);
		}
	}
return null();
}


HX_DEFINE_DYNAMIC_FUNC0(DeeplyRootedClass_obj,deeplyRootedMethod,(void))


DeeplyRootedClass_obj::DeeplyRootedClass_obj()
{
}

Dynamic DeeplyRootedClass_obj::__Field(const ::String &inName,hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"toll") ) { return toll; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"optional") ) { return optional; }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"fantastisch") ) { return fantastisch; }
		break;
	case 18:
		if (HX_FIELD_EQ(inName,"deeplyRootedMethod") ) { return deeplyRootedMethod_dyn(); }
	}
	return super::__Field(inName,inCallProp);
}

Dynamic DeeplyRootedClass_obj::__SetField(const ::String &inName,const Dynamic &inValue,hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"toll") ) { toll=inValue.Cast< int >(); return inValue; }
		break;
	case 8:
		if (HX_FIELD_EQ(inName,"optional") ) { optional=inValue.Cast< bool >(); return inValue; }
		break;
	case 11:
		if (HX_FIELD_EQ(inName,"fantastisch") ) { fantastisch=inValue.Cast< int >(); return inValue; }
	}
	return super::__SetField(inName,inValue,inCallProp);
}

bool DeeplyRootedClass_obj::__SetStatic(const ::String &inName,Dynamic &ioValue,hx::PropertyAccess inCallProp)
{
	return false;
}

void DeeplyRootedClass_obj::__GetFields(Array< ::String> &outFields)
{
	outFields->push(HX_HCSTRING("fantastisch","\x30","\xc5","\x53","\x90"));
	outFields->push(HX_HCSTRING("toll","\xbb","\x58","\x01","\x4d"));
	outFields->push(HX_HCSTRING("optional","\xa0","\xaf","\x6e","\x1e"));
	super::__GetFields(outFields);
};

#if HXCPP_SCRIPTABLE
static hx::StorageInfo sMemberStorageInfo[] = {
	{hx::fsInt,(int)offsetof(DeeplyRootedClass_obj,fantastisch),HX_HCSTRING("fantastisch","\x30","\xc5","\x53","\x90")},
	{hx::fsInt,(int)offsetof(DeeplyRootedClass_obj,toll),HX_HCSTRING("toll","\xbb","\x58","\x01","\x4d")},
	{hx::fsBool,(int)offsetof(DeeplyRootedClass_obj,optional),HX_HCSTRING("optional","\xa0","\xaf","\x6e","\x1e")},
	{ hx::fsUnknown, 0, null()}
};
static hx::StaticInfo *sStaticStorageInfo = 0;
#endif

static ::String sMemberFields[] = {
	HX_HCSTRING("fantastisch","\x30","\xc5","\x53","\x90"),
	HX_HCSTRING("toll","\xbb","\x58","\x01","\x4d"),
	HX_HCSTRING("optional","\xa0","\xaf","\x6e","\x1e"),
	HX_HCSTRING("deeplyRootedMethod","\x1b","\xc6","\x13","\xa9"),
	::String(null()) };

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(DeeplyRootedClass_obj::__mClass,"__mClass");
};

#ifdef HXCPP_VISIT_ALLOCS
static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(DeeplyRootedClass_obj::__mClass,"__mClass");
};

#endif

hx::Class DeeplyRootedClass_obj::__mClass;

void DeeplyRootedClass_obj::__register()
{
	hx::Static(__mClass) = new hx::Class_obj();
	__mClass->mName = HX_HCSTRING("tryOut.packageLevel02.packageLevel03.DeeplyRootedClass","\x44","\xce","\x59","\x22");
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &hx::Class_obj::GetNoStaticField;
	__mClass->mSetStaticField = &DeeplyRootedClass_obj::__SetStatic;
	__mClass->mMarkFunc = sMarkStatics;
	__mClass->mStatics = hx::Class_obj::dupFunctions(0 /* sStaticFields */);
	__mClass->mMembers = hx::Class_obj::dupFunctions(sMemberFields);
	__mClass->mCanCast = hx::TCanCast< DeeplyRootedClass_obj >;
#ifdef HXCPP_VISIT_ALLOCS
	__mClass->mVisitFunc = sVisitStatics;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = sStaticStorageInfo;
#endif
	hx::RegisterClass(__mClass->mName, __mClass);
}

} // end namespace tryOut
} // end namespace packageLevel02
} // end namespace packageLevel03
