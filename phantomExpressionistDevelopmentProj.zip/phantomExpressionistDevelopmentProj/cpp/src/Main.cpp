#include <hxcpp.h>

#ifndef INCLUDED_EReg
#include <EReg.h>
#endif
#ifndef INCLUDED_Main
#include <Main.h>
#endif
#ifndef INCLUDED_Std
#include <Std.h>
#endif
#ifndef INCLUDED_haxe_Log
#include <haxe/Log.h>
#endif
#ifndef INCLUDED_haxe_io_Input
#include <haxe/io/Input.h>
#endif
#ifndef INCLUDED_haxe_macro_Constant
#include <haxe/macro/Constant.h>
#endif
#ifndef INCLUDED_haxe_macro_ExprDef
#include <haxe/macro/ExprDef.h>
#endif
#ifndef INCLUDED_sys_io_File
#include <sys/io/File.h>
#endif
#ifndef INCLUDED_sys_io_FileInput
#include <sys/io/FileInput.h>
#endif
#ifndef INCLUDED_tryOut_TryOut
#include <tryOut/TryOut.h>
#endif
#ifndef INCLUDED_tryOut_packageLevel02_packageLevel03_DeeplyRootedClass
#include <tryOut/packageLevel02/packageLevel03/DeeplyRootedClass.h>
#endif

Void Main_obj::__construct()
{
	return null();
}

//Main_obj::~Main_obj() { }

Dynamic Main_obj::__CreateEmpty() { return  new Main_obj; }
hx::ObjectPtr< Main_obj > Main_obj::__new()
{  hx::ObjectPtr< Main_obj > _result_ = new Main_obj();
	_result_->__construct();
	return _result_;}

Dynamic Main_obj::__Create(hx::DynamicArray inArgs)
{  hx::ObjectPtr< Main_obj > _result_ = new Main_obj();
	_result_->__construct();
	return _result_;}

Void Main_obj::main( ){
{
		HX_STACK_FRAME("Main","main",0xed0e206e,"Main.main","Main.hx",14,0x087e5c05)
		HX_STACK_LINE(21)
		::haxe::macro::Constant tmp = ::haxe::macro::Constant_obj::CIdent(HX_HCSTRING("trace","\x85","\x8e","\x1f","\x16"));		HX_STACK_VAR(tmp,"tmp");
		HX_STACK_LINE(21)
		::haxe::macro::ExprDef tmp1 = ::haxe::macro::ExprDef_obj::EConst(tmp);		HX_STACK_VAR(tmp1,"tmp1");
		struct _Function_1_1{
			inline static Dynamic Block( ){
				HX_STACK_FRAME("*","closure",0x5bdab937,"*.closure","Main.hx",21,0x087e5c05)
				{
					hx::Anon __result = hx::Anon_obj::Create();
					__result->Add(HX_HCSTRING("file","\x7c","\xce","\xbb","\x43") , HX_HCSTRING("src/Main.hx","\x9a","\x7a","\x30","\xa1"),false);
					__result->Add(HX_HCSTRING("min","\x92","\x11","\x53","\x00") , (int)439,false);
					__result->Add(HX_HCSTRING("max","\xa4","\x0a","\x53","\x00") , (int)444,false);
					return __result;
				}
				return null();
			}
		};
		HX_STACK_LINE(21)
		Dynamic tmp2 = _Function_1_1::Block();		HX_STACK_VAR(tmp2,"tmp2");
		struct _Function_1_2{
			inline static Dynamic Block( Dynamic &tmp2,::haxe::macro::ExprDef &tmp1){
				HX_STACK_FRAME("*","closure",0x5bdab937,"*.closure","Main.hx",21,0x087e5c05)
				{
					hx::Anon __result = hx::Anon_obj::Create();
					__result->Add(HX_HCSTRING("expr","\x35","\xfd","\x1d","\x43") , tmp1,false);
					__result->Add(HX_HCSTRING("pos","\x94","\x5d","\x55","\x00") , tmp2,false);
					return __result;
				}
				return null();
			}
		};
		HX_STACK_LINE(21)
		Dynamic tmp3 = _Function_1_2::Block(tmp2,tmp1);		HX_STACK_VAR(tmp3,"tmp3");
		HX_STACK_LINE(21)
		::haxe::macro::Constant tmp4 = ::haxe::macro::Constant_obj::CString(HX_HCSTRING("Toll, das erste Macro ist gesetzt.","\x7c","\xc0","\x9c","\x54"));		HX_STACK_VAR(tmp4,"tmp4");
		HX_STACK_LINE(21)
		::haxe::macro::ExprDef tmp5 = ::haxe::macro::ExprDef_obj::EConst(tmp4);		HX_STACK_VAR(tmp5,"tmp5");
		struct _Function_1_3{
			inline static Dynamic Block( ){
				HX_STACK_FRAME("*","closure",0x5bdab937,"*.closure","Main.hx",21,0x087e5c05)
				{
					hx::Anon __result = hx::Anon_obj::Create();
					__result->Add(HX_HCSTRING("file","\x7c","\xce","\xbb","\x43") , HX_HCSTRING("src/Main.hx","\x9a","\x7a","\x30","\xa1"),false);
					__result->Add(HX_HCSTRING("min","\x92","\x11","\x53","\x00") , (int)446,false);
					__result->Add(HX_HCSTRING("max","\xa4","\x0a","\x53","\x00") , (int)482,false);
					return __result;
				}
				return null();
			}
		};
		HX_STACK_LINE(21)
		Dynamic tmp6 = _Function_1_3::Block();		HX_STACK_VAR(tmp6,"tmp6");
		struct _Function_1_4{
			inline static Dynamic Block( ::haxe::macro::ExprDef &tmp5,Dynamic &tmp6){
				HX_STACK_FRAME("*","closure",0x5bdab937,"*.closure","Main.hx",21,0x087e5c05)
				{
					hx::Anon __result = hx::Anon_obj::Create();
					__result->Add(HX_HCSTRING("expr","\x35","\xfd","\x1d","\x43") , tmp5,false);
					__result->Add(HX_HCSTRING("pos","\x94","\x5d","\x55","\x00") , tmp6,false);
					return __result;
				}
				return null();
			}
		};
		HX_STACK_LINE(21)
		Dynamic tmp7 = _Function_1_4::Block(tmp5,tmp6);		HX_STACK_VAR(tmp7,"tmp7");
		HX_STACK_LINE(21)
		::haxe::macro::ExprDef tmp8 = ::haxe::macro::ExprDef_obj::ECall(tmp3,cpp::ArrayBase_obj::__new().Add(tmp7));		HX_STACK_VAR(tmp8,"tmp8");
		struct _Function_1_5{
			inline static Dynamic Block( ){
				HX_STACK_FRAME("*","closure",0x5bdab937,"*.closure","Main.hx",21,0x087e5c05)
				{
					hx::Anon __result = hx::Anon_obj::Create();
					__result->Add(HX_HCSTRING("file","\x7c","\xce","\xbb","\x43") , HX_HCSTRING("src/Main.hx","\x9a","\x7a","\x30","\xa1"),false);
					__result->Add(HX_HCSTRING("min","\x92","\x11","\x53","\x00") , (int)439,false);
					__result->Add(HX_HCSTRING("max","\xa4","\x0a","\x53","\x00") , (int)485,false);
					return __result;
				}
				return null();
			}
		};
		HX_STACK_LINE(21)
		Dynamic tmp9 = _Function_1_5::Block();		HX_STACK_VAR(tmp9,"tmp9");
		struct _Function_1_6{
			inline static Dynamic Block( Dynamic &tmp9,::haxe::macro::ExprDef &tmp8){
				HX_STACK_FRAME("*","closure",0x5bdab937,"*.closure","Main.hx",21,0x087e5c05)
				{
					hx::Anon __result = hx::Anon_obj::Create();
					__result->Add(HX_HCSTRING("expr","\x35","\xfd","\x1d","\x43") , tmp8,false);
					__result->Add(HX_HCSTRING("pos","\x94","\x5d","\x55","\x00") , tmp9,false);
					return __result;
				}
				return null();
			}
		};
		HX_STACK_LINE(21)
		Dynamic tmp10 = _Function_1_6::Block(tmp9,tmp8);		HX_STACK_VAR(tmp10,"tmp10");
		HX_STACK_LINE(20)
		::haxe::macro::ExprDef tmp11 = ::haxe::macro::ExprDef_obj::EBlock(cpp::ArrayBase_obj::__new().Add(tmp10));		HX_STACK_VAR(tmp11,"tmp11");
		struct _Function_1_7{
			inline static Dynamic Block( ){
				HX_STACK_FRAME("*","closure",0x5bdab937,"*.closure","Main.hx",20,0x087e5c05)
				{
					hx::Anon __result = hx::Anon_obj::Create();
					__result->Add(HX_HCSTRING("file","\x7c","\xce","\xbb","\x43") , HX_HCSTRING("src/Main.hx","\x9a","\x7a","\x30","\xa1"),false);
					__result->Add(HX_HCSTRING("min","\x92","\x11","\x53","\x00") , (int)424,false);
					__result->Add(HX_HCSTRING("max","\xa4","\x0a","\x53","\x00") , (int)493,false);
					return __result;
				}
				return null();
			}
		};
		HX_STACK_LINE(20)
		Dynamic tmp12 = _Function_1_7::Block();		HX_STACK_VAR(tmp12,"tmp12");
		struct _Function_1_8{
			inline static Dynamic Block( ::haxe::macro::ExprDef &tmp11,Dynamic &tmp12){
				HX_STACK_FRAME("*","closure",0x5bdab937,"*.closure","Main.hx",20,0x087e5c05)
				{
					hx::Anon __result = hx::Anon_obj::Create();
					__result->Add(HX_HCSTRING("expr","\x35","\xfd","\x1d","\x43") , tmp11,false);
					__result->Add(HX_HCSTRING("pos","\x94","\x5d","\x55","\x00") , tmp12,false);
					return __result;
				}
				return null();
			}
		};
		HX_STACK_LINE(20)
		Dynamic tmp13 = _Function_1_8::Block(tmp11,tmp12);		HX_STACK_VAR(tmp13,"tmp13");
		HX_STACK_LINE(20)
		tmp13;
		HX_STACK_LINE(34)
		int toll = (int)4;		HX_STACK_VAR(toll,"toll");
		HX_STACK_LINE(56)
		int tmp14 = (int)4;		HX_STACK_VAR(tmp14,"tmp14");
		HX_STACK_LINE(56)
		int ganzToll = tmp14;		HX_STACK_VAR(ganzToll,"ganzToll");
		HX_STACK_LINE(57)
		int fantastisch;		HX_STACK_VAR(fantastisch,"fantastisch");
		HX_STACK_LINE(59)
		int aComplexExpressionVariable = (int)0;		HX_STACK_VAR(aComplexExpressionVariable,"aComplexExpressionVariable");
		HX_STACK_LINE(61)
		int tmp15 = (int)7;		HX_STACK_VAR(tmp15,"tmp15");
		HX_STACK_LINE(61)
		int tmp16 = (tmp15 + (int)5);		HX_STACK_VAR(tmp16,"tmp16");
		HX_STACK_LINE(61)
		int tmp17 = ganzToll;		HX_STACK_VAR(tmp17,"tmp17");
		HX_STACK_LINE(61)
		int tmp18 = (tmp16 + tmp17);		HX_STACK_VAR(tmp18,"tmp18");
		HX_STACK_LINE(61)
		int tmp19 = (tmp18 + (int)6);		HX_STACK_VAR(tmp19,"tmp19");
		HX_STACK_LINE(61)
		aComplexExpressionVariable = tmp19;
		HX_STACK_LINE(63)
		int anotherComplexExpression;		HX_STACK_VAR(anotherComplexExpression,"anotherComplexExpression");
		HX_STACK_LINE(65)
		int tmp20 = (int)5;		HX_STACK_VAR(tmp20,"tmp20");
		HX_STACK_LINE(65)
		int tmp21 = (tmp20 * (int)5);		HX_STACK_VAR(tmp21,"tmp21");
		HX_STACK_LINE(65)
		int tmp22 = ((int)3 + tmp21);		HX_STACK_VAR(tmp22,"tmp22");
		HX_STACK_LINE(65)
		anotherComplexExpression = tmp22;
		HX_STACK_LINE(67)
		int theOrderMatters;		HX_STACK_VAR(theOrderMatters,"theOrderMatters");
		HX_STACK_LINE(69)
		int tmp23 = (int)5;		HX_STACK_VAR(tmp23,"tmp23");
		HX_STACK_LINE(69)
		int tmp24 = ((int)5 * tmp23);		HX_STACK_VAR(tmp24,"tmp24");
		HX_STACK_LINE(69)
		int tmp25 = ((int)3 + tmp24);		HX_STACK_VAR(tmp25,"tmp25");
		HX_STACK_LINE(69)
		theOrderMatters = tmp25;
		HX_STACK_LINE(72)
		bool aBoolean = true;		HX_STACK_VAR(aBoolean,"aBoolean");
		HX_STACK_LINE(74)
		toll;
		HX_STACK_LINE(77)
		(toll)++;
		HX_STACK_LINE(79)
		toll = (int)231;
		HX_STACK_LINE(85)
		hx::AddEq(toll,ganzToll);
		HX_STACK_LINE(91)
		int tmp26 = (toll + (int)20);		HX_STACK_VAR(tmp26,"tmp26");
		HX_STACK_LINE(91)
		toll = tmp26;
		HX_STACK_LINE(93)
		fantastisch = (int)113;
		HX_STACK_LINE(94)
		int tmp27 = (fantastisch + ganzToll);		HX_STACK_VAR(tmp27,"tmp27");
		HX_STACK_LINE(94)
		int tmp28 = toll;		HX_STACK_VAR(tmp28,"tmp28");
		HX_STACK_LINE(94)
		int tmp29 = (tmp27 + tmp28);		HX_STACK_VAR(tmp29,"tmp29");
		HX_STACK_LINE(94)
		fantastisch = tmp29;
		HX_STACK_LINE(95)
		hx::AddEq(fantastisch,(int)210);
		HX_STACK_LINE(110)
		bool tmp30 = (toll < (int)33);		HX_STACK_VAR(tmp30,"tmp30");
		HX_STACK_LINE(110)
		if ((tmp30)){
			HX_STACK_LINE(112)
			Dynamic tmp31 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),112,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp31,"tmp31");
			HX_STACK_LINE(112)
			::haxe::Log_obj::trace(HX_HCSTRING("Hm, 'toll' ist ja gar nicht so toll...","\x94","\x0f","\xac","\xa3"),tmp31);
			HX_STACK_LINE(113)
			hx::MultEq(fantastisch,(int)2);
		}
		else{
			HX_STACK_LINE(117)
			hx::AddEq(fantastisch,(int)2);
			HX_STACK_LINE(118)
			Dynamic tmp31 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),118,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp31,"tmp31");
			HX_STACK_LINE(118)
			::haxe::Log_obj::trace(HX_HCSTRING("","\x00","\x00","\x00","\x00"),tmp31);
			HX_STACK_LINE(119)
			::String tmp32 = (HX_HCSTRING("fantastisch: ","\xd6","\xa3","\xb3","\x20") + fantastisch);		HX_STACK_VAR(tmp32,"tmp32");
			HX_STACK_LINE(119)
			Dynamic tmp33 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),119,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp33,"tmp33");
			HX_STACK_LINE(119)
			::haxe::Log_obj::trace(tmp32,tmp33);
			HX_STACK_LINE(120)
			Float tmp34 = (Float(fantastisch) / Float((int)3));		HX_STACK_VAR(tmp34,"tmp34");
			HX_STACK_LINE(120)
			int tmp35 = ::Std_obj::_int(tmp34);		HX_STACK_VAR(tmp35,"tmp35");
			HX_STACK_LINE(120)
			fantastisch = tmp35;
		}
		HX_STACK_LINE(123)
		bool tmp31 = (toll > (int)1005);		HX_STACK_VAR(tmp31,"tmp31");
		HX_STACK_LINE(123)
		if ((tmp31)){
			HX_STACK_LINE(124)
			hx::AddEq(fantastisch,(int)10);
		}
		else{
			HX_STACK_LINE(126)
			hx::SubEq(fantastisch,(int)10);
		}
		HX_STACK_LINE(135)
		int tmp32 = fantastisch;		HX_STACK_VAR(tmp32,"tmp32");
		HX_STACK_LINE(135)
		switch( (int)(tmp32)){
			case (int)1: {
				HX_STACK_LINE(137)
				Dynamic tmp33 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),137,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp33,"tmp33");
				HX_STACK_LINE(137)
				::haxe::Log_obj::trace(HX_HCSTRING("1","\x31","\x00","\x00","\x00"),tmp33);
			}
			;break;
			case (int)2: {
				HX_STACK_LINE(152)
				Dynamic tmp33 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),152,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp33,"tmp33");
				HX_STACK_LINE(152)
				::haxe::Log_obj::trace(HX_HCSTRING("2","\x32","\x00","\x00","\x00"),tmp33);
			}
			;break;
			case (int)3: {
				HX_STACK_LINE(153)
				Dynamic tmp33 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),153,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp33,"tmp33");
				HX_STACK_LINE(153)
				::haxe::Log_obj::trace(HX_HCSTRING("3","\x33","\x00","\x00","\x00"),tmp33);
			}
			;break;
			case (int)4: {
				HX_STACK_LINE(154)
				Dynamic tmp33 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),154,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp33,"tmp33");
				HX_STACK_LINE(154)
				::haxe::Log_obj::trace(HX_HCSTRING("4","\x34","\x00","\x00","\x00"),tmp33);
			}
			;break;
			case (int)5: {
				HX_STACK_LINE(155)
				Dynamic tmp33 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),155,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp33,"tmp33");
				HX_STACK_LINE(155)
				::haxe::Log_obj::trace(HX_HCSTRING("5","\x35","\x00","\x00","\x00"),tmp33);
			}
			;break;
			case (int)6: case (int)7: case (int)8: {
				HX_STACK_LINE(156)
				Dynamic tmp33 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),156,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp33,"tmp33");
				HX_STACK_LINE(156)
				::haxe::Log_obj::trace(HX_HCSTRING("6, 7 oder 8","\x4d","\xf0","\x31","\x4f"),tmp33);
			}
			;break;
			case (int)9: {
			}
			;break;
			default: {
				HX_STACK_LINE(158)
				Dynamic tmp33 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),158,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp33,"tmp33");
				HX_STACK_LINE(158)
				::haxe::Log_obj::trace(HX_HCSTRING("Default Case","\xaf","\xf2","\xa5","\x83"),tmp33);
			}
		}
		HX_STACK_LINE(162)
		::String forTheSwitch = HX_HCSTRING("toll","\xbb","\x58","\x01","\x4d");		HX_STACK_VAR(forTheSwitch,"forTheSwitch");
		HX_STACK_LINE(164)
		::String tmp33 = forTheSwitch;		HX_STACK_VAR(tmp33,"tmp33");
		HX_STACK_LINE(164)
		::String _switch_1 = (tmp33);
		if (  ( _switch_1==HX_HCSTRING("toll","\xbb","\x58","\x01","\x4d"))){
			HX_STACK_LINE(169)
			Dynamic tmp34 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),169,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp34,"tmp34");
			HX_STACK_LINE(169)
			::haxe::Log_obj::trace(HX_HCSTRING("toll","\xbb","\x58","\x01","\x4d"),tmp34);
			HX_STACK_LINE(170)
			fantastisch = (int)3;
		}
		else if (  ( _switch_1==HX_HCSTRING("fantastisch","\x30","\xc5","\x53","\x90"))){
			HX_STACK_LINE(174)
			Dynamic tmp34 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),174,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp34,"tmp34");
			HX_STACK_LINE(174)
			::haxe::Log_obj::trace(HX_HCSTRING("fantastisch","\x30","\xc5","\x53","\x90"),tmp34);
			HX_STACK_LINE(175)
			fantastisch = (int)4;
		}
		else  {
			HX_STACK_LINE(179)
			Dynamic tmp34 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),179,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp34,"tmp34");
			HX_STACK_LINE(179)
			::haxe::Log_obj::trace(HX_HCSTRING("default","\xc1","\xd8","\xc3","\x9b"),tmp34);
			HX_STACK_LINE(180)
			fantastisch = (int)6;
		}
;
;
		HX_STACK_LINE(185)
		bool tmp34 = (fantastisch > toll);		HX_STACK_VAR(tmp34,"tmp34");
		HX_STACK_LINE(185)
		int tmp35;		HX_STACK_VAR(tmp35,"tmp35");
		HX_STACK_LINE(185)
		if ((tmp34)){
			HX_STACK_LINE(185)
			Float tmp36 = (Float(ganzToll) / Float((int)4));		HX_STACK_VAR(tmp36,"tmp36");
			HX_STACK_LINE(185)
			tmp35 = ::Std_obj::_int(tmp36);
		}
		else{
			HX_STACK_LINE(185)
			tmp35 = (ganzToll * (int)5);
		}
		HX_STACK_LINE(185)
		ganzToll = tmp35;
		HX_STACK_LINE(187)
		::tryOut::TryOut tmp36 = ::tryOut::TryOut_obj::__new((int)3,((Float)2.5),HX_HCSTRING("Drei","\x92","\x5b","\x49","\x2d"));		HX_STACK_VAR(tmp36,"tmp36");
		HX_STACK_LINE(187)
		::tryOut::TryOut tryOut1 = tmp36;		HX_STACK_VAR(tryOut1,"tryOut1");
		HX_STACK_LINE(193)
		int counter = (int)3;		HX_STACK_VAR(counter,"counter");
		HX_STACK_LINE(194)
		while((true)){
			HX_STACK_LINE(194)
			bool tmp37 = (counter > (int)1);		HX_STACK_VAR(tmp37,"tmp37");
			HX_STACK_LINE(194)
			bool tmp38 = !(tmp37);		HX_STACK_VAR(tmp38,"tmp38");
			HX_STACK_LINE(194)
			if ((tmp38)){
				HX_STACK_LINE(194)
				break;
			}
			HX_STACK_LINE(196)
			hx::SubEq(counter,(int)1);
		}
		HX_STACK_LINE(199)
		counter = (int)3;
		HX_STACK_LINE(200)
		while((true)){
			HX_STACK_LINE(203)
			hx::SubEq(counter,(int)1);
			HX_STACK_LINE(204)
			bool tmp37 = (counter > (int)1);		HX_STACK_VAR(tmp37,"tmp37");
			HX_STACK_LINE(204)
			bool tmp38 = !(tmp37);		HX_STACK_VAR(tmp38,"tmp38");
			HX_STACK_LINE(200)
			if ((tmp38)){
				HX_STACK_LINE(200)
				break;
			}
		}
		HX_STACK_LINE(206)
		{
			HX_STACK_LINE(206)
			int _g = (int)0;		HX_STACK_VAR(_g,"_g");
			HX_STACK_LINE(206)
			while((true)){
				HX_STACK_LINE(206)
				bool tmp37 = (_g < (int)10);		HX_STACK_VAR(tmp37,"tmp37");
				HX_STACK_LINE(206)
				bool tmp38 = !(tmp37);		HX_STACK_VAR(tmp38,"tmp38");
				HX_STACK_LINE(206)
				if ((tmp38)){
					HX_STACK_LINE(206)
					break;
				}
				HX_STACK_LINE(206)
				int tmp39 = (_g)++;		HX_STACK_VAR(tmp39,"tmp39");
				HX_STACK_LINE(206)
				int i = tmp39;		HX_STACK_VAR(i,"i");
				HX_STACK_LINE(208)
				int tmp40 = i;		HX_STACK_VAR(tmp40,"tmp40");
				HX_STACK_LINE(208)
				Dynamic tmp41 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),208,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp41,"tmp41");
				HX_STACK_LINE(208)
				::haxe::Log_obj::trace(tmp40,tmp41);
			}
		}
		HX_STACK_LINE(211)
		try
		{
		HX_STACK_CATCHABLE(::String, 0);
		{
			HX_STACK_LINE(213)
			Dynamic tmp37 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),213,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp37,"tmp37");
			HX_STACK_LINE(213)
			::haxe::Log_obj::trace(HX_HCSTRING("Try-Block","\x3b","\x89","\x8b","\x9d"),tmp37);
			HX_STACK_LINE(214)
			::sys::io::FileInput tmp38 = ::sys::io::File_obj::read(HX_HCSTRING("k:/thisfolder/does/not/exist","\xe8","\x87","\x9d","\xec"),false);		HX_STACK_VAR(tmp38,"tmp38");
			HX_STACK_LINE(214)
			::sys::io::FileInput toll1 = tmp38;		HX_STACK_VAR(toll1,"toll1");
		}
		}
		catch(Dynamic __e){
			if (__e.IsClass< ::String >() ){
				HX_STACK_BEGIN_CATCH
				::String e = __e;{
					HX_STACK_LINE(220)
					Dynamic tmp37 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),220,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp37,"tmp37");
					HX_STACK_LINE(220)
					::haxe::Log_obj::trace(HX_HCSTRING("Catch-Block","\x3b","\x94","\x44","\x75"),tmp37);
					HX_STACK_LINE(221)
					Dynamic tmp38 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),221,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp38,"tmp38");
					HX_STACK_LINE(221)
					::haxe::Log_obj::trace(HX_HCSTRING("Error Message:","\x2b","\xc4","\x24","\xbe"),tmp38);
					HX_STACK_LINE(222)
					::String tmp39 = e;		HX_STACK_VAR(tmp39,"tmp39");
					HX_STACK_LINE(222)
					Dynamic tmp40 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),222,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp40,"tmp40");
					HX_STACK_LINE(222)
					::haxe::Log_obj::trace(tmp39,tmp40);
				}
			}
			else {
			    HX_STACK_DO_THROW(__e);
			}
		}
		HX_STACK_LINE(225)
		try
		{
		HX_STACK_CATCHABLE(::String, 0);
		{
			HX_STACK_LINE(227)
			Dynamic tmp37 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),227,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp37,"tmp37");
			HX_STACK_LINE(227)
			::haxe::Log_obj::trace(HX_HCSTRING("Where-Is-My-Catch-Block-Experiment","\x53","\xea","\x07","\x63"),tmp37);
		}
		}
		catch(Dynamic __e){
			if (__e.IsClass< ::String >() ){
				HX_STACK_BEGIN_CATCH
				::String e = __e;{
					HX_STACK_LINE(240)
					Dynamic tmp37 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),240,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp37,"tmp37");
					HX_STACK_LINE(240)
					::haxe::Log_obj::trace(HX_HCSTRING("Catch-Block","\x3b","\x94","\x44","\x75"),tmp37);
					HX_STACK_LINE(241)
					Dynamic tmp38 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),241,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp38,"tmp38");
					HX_STACK_LINE(241)
					::haxe::Log_obj::trace(HX_HCSTRING("Error Message:","\x2b","\xc4","\x24","\xbe"),tmp38);
					HX_STACK_LINE(242)
					::String tmp39 = e;		HX_STACK_VAR(tmp39,"tmp39");
					HX_STACK_LINE(242)
					Dynamic tmp40 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),242,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp40,"tmp40");
					HX_STACK_LINE(242)
					::haxe::Log_obj::trace(tmp39,tmp40);
				}
			}
			else {
			    HX_STACK_DO_THROW(__e);
			}
		}
		HX_STACK_LINE(255)
		Dynamic tmp37 = ::tryOut::TryOut_obj::tollFn_dyn();		HX_STACK_VAR(tmp37,"tmp37");
		HX_STACK_LINE(255)
		::tryOut::TryOut_obj::executeVoidFn(tmp37);
		HX_STACK_LINE(257)
		Dynamic tmp38 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),257,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp38,"tmp38");
		HX_STACK_LINE(257)
		::haxe::Log_obj::trace(HX_HCSTRING("RegEx-Test","\xf8","\x1a","\x5c","\x25"),tmp38);
		HX_STACK_LINE(258)
		::EReg tmp39 = ::EReg_obj::__new(HX_HCSTRING("([0-9]+)","\x92","\x58","\x20","\xf8"),HX_HCSTRING("","\x00","\x00","\x00","\x00"));		HX_STACK_VAR(tmp39,"tmp39");
		HX_STACK_LINE(258)
		::EReg regEx01 = tmp39;		HX_STACK_VAR(regEx01,"regEx01");
		HX_STACK_LINE(259)
		::EReg tmp40 = ::EReg_obj::__new(HX_HCSTRING("([a-zA-Z]+)","\x28","\x49","\xc9","\x6b"),HX_HCSTRING("","\x00","\x00","\x00","\x00"));		HX_STACK_VAR(tmp40,"tmp40");
		HX_STACK_LINE(259)
		::EReg regEx02 = tmp40;		HX_STACK_VAR(regEx02,"regEx02");
		HX_STACK_LINE(260)
		::String testString = HX_HCSTRING("aberAber 099098","\x63","\x27","\x0b","\x28");		HX_STACK_VAR(testString,"testString");
		HX_STACK_LINE(262)
		::String tmp41 = testString;		HX_STACK_VAR(tmp41,"tmp41");
		HX_STACK_LINE(262)
		bool tmp42 = regEx01->match(tmp41);		HX_STACK_VAR(tmp42,"tmp42");
		HX_STACK_LINE(262)
		if ((tmp42)){
			HX_STACK_LINE(264)
			Dynamic tmp43 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),264,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp43,"tmp43");
			HX_STACK_LINE(264)
			::haxe::Log_obj::trace(HX_HCSTRING("The matched numbers:","\xdb","\xd2","\x1a","\x9c"),tmp43);
			HX_STACK_LINE(265)
			::String tmp44 = regEx01->matched((int)1);		HX_STACK_VAR(tmp44,"tmp44");
			HX_STACK_LINE(265)
			Dynamic tmp45 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),265,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp45,"tmp45");
			HX_STACK_LINE(265)
			::haxe::Log_obj::trace(tmp44,tmp45);
		}
		HX_STACK_LINE(268)
		::String tmp43 = testString;		HX_STACK_VAR(tmp43,"tmp43");
		HX_STACK_LINE(268)
		bool tmp44 = regEx02->match(tmp43);		HX_STACK_VAR(tmp44,"tmp44");
		HX_STACK_LINE(268)
		if ((tmp44)){
			HX_STACK_LINE(270)
			Dynamic tmp45 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),270,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp45,"tmp45");
			HX_STACK_LINE(270)
			::haxe::Log_obj::trace(HX_HCSTRING("The matched letters:","\x38","\x7a","\x14","\xba"),tmp45);
			HX_STACK_LINE(271)
			::String tmp46 = regEx02->matched((int)1);		HX_STACK_VAR(tmp46,"tmp46");
			HX_STACK_LINE(271)
			Dynamic tmp47 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),271,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp47,"tmp47");
			HX_STACK_LINE(271)
			::haxe::Log_obj::trace(tmp46,tmp47);
		}
		HX_STACK_LINE(274)
		::tryOut::packageLevel02::packageLevel03::DeeplyRootedClass tmp45 = ::tryOut::packageLevel02::packageLevel03::DeeplyRootedClass_obj::__new((int)11,(int)43,null());		HX_STACK_VAR(tmp45,"tmp45");
		HX_STACK_LINE(274)
		::tryOut::packageLevel02::packageLevel03::DeeplyRootedClass deeplyRooted = tmp45;		HX_STACK_VAR(deeplyRooted,"deeplyRooted");
		HX_STACK_LINE(276)
		int tmp46 = deeplyRooted->fantastisch;		HX_STACK_VAR(tmp46,"tmp46");
		HX_STACK_LINE(276)
		Dynamic tmp47 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),276,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp47,"tmp47");
		HX_STACK_LINE(276)
		::haxe::Log_obj::trace(tmp46,tmp47);
		HX_STACK_LINE(278)
		::tryOut::packageLevel02::packageLevel03::DeeplyRootedClass tmp48 = ::tryOut::packageLevel02::packageLevel03::DeeplyRootedClass_obj::__new((int)11,(int)43,true);		HX_STACK_VAR(tmp48,"tmp48");
		HX_STACK_LINE(278)
		::tryOut::packageLevel02::packageLevel03::DeeplyRootedClass deeplyRootedPlusOptional = tmp48;		HX_STACK_VAR(deeplyRootedPlusOptional,"deeplyRootedPlusOptional");

		HX_BEGIN_LOCAL_FUNC_S0(hx::LocalFunc,_Function_1_9)
		int __ArgCount() const { return 2; }
		int run(int int01,int int02){
			HX_STACK_FRAME("*","_Function_1_9",0x5200ed3f,"*._Function_1_9","Main.hx",281,0x087e5c05)
			HX_STACK_ARG(int01,"int01")
			HX_STACK_ARG(int02,"int02")
			{
				HX_STACK_LINE(282)
				int tmp49 = (int01 + int02);		HX_STACK_VAR(tmp49,"tmp49");
				HX_STACK_LINE(282)
				return tmp49;
			}
			return null();
		}
		HX_END_LOCAL_FUNC2(return)

		HX_STACK_LINE(280)
		Dynamic withinMainFunc =  Dynamic(new _Function_1_9());		HX_STACK_VAR(withinMainFunc,"withinMainFunc");
		HX_STACK_LINE(285)
		int tmp49 = withinMainFunc((int)3,(int)4).Cast< int >();		HX_STACK_VAR(tmp49,"tmp49");
		HX_STACK_LINE(285)
		Dynamic tmp50 = hx::SourceInfo(HX_HCSTRING("Main.hx","\x05","\x5c","\x7e","\x08"),285,HX_HCSTRING("Main","\x59","\x64","\x2f","\x33"),HX_HCSTRING("main","\x39","\x38","\x56","\x48"));		HX_STACK_VAR(tmp50,"tmp50");
		HX_STACK_LINE(285)
		::haxe::Log_obj::trace(tmp49,tmp50);
		HX_STACK_LINE(287)
		HX_HCSTRING("<endStatement>","\x2e","\xa3","\xe2","\x95");
	}
return null();
}


STATIC_HX_DEFINE_DYNAMIC_FUNC0(Main_obj,main,(void))


Main_obj::Main_obj()
{
}

bool Main_obj::__GetStatic(const ::String &inName, Dynamic &outValue, hx::PropertyAccess inCallProp)
{
	switch(inName.length) {
	case 4:
		if (HX_FIELD_EQ(inName,"main") ) { outValue = main_dyn(); return true;  }
	}
	return false;
}

#if HXCPP_SCRIPTABLE
static hx::StorageInfo *sMemberStorageInfo = 0;
static hx::StaticInfo *sStaticStorageInfo = 0;
#endif

static void sMarkStatics(HX_MARK_PARAMS) {
	HX_MARK_MEMBER_NAME(Main_obj::__mClass,"__mClass");
};

#ifdef HXCPP_VISIT_ALLOCS
static void sVisitStatics(HX_VISIT_PARAMS) {
	HX_VISIT_MEMBER_NAME(Main_obj::__mClass,"__mClass");
};

#endif

hx::Class Main_obj::__mClass;

static ::String sStaticFields[] = {
	HX_HCSTRING("main","\x39","\x38","\x56","\x48"),
	::String(null()) };

void Main_obj::__register()
{
	hx::Static(__mClass) = new hx::Class_obj();
	__mClass->mName = HX_HCSTRING("Main","\x59","\x64","\x2f","\x33");
	__mClass->mSuper = &super::__SGetClass();
	__mClass->mConstructEmpty = &__CreateEmpty;
	__mClass->mConstructArgs = &__Create;
	__mClass->mGetStaticField = &Main_obj::__GetStatic;
	__mClass->mSetStaticField = &hx::Class_obj::SetNoStaticField;
	__mClass->mMarkFunc = sMarkStatics;
	__mClass->mStatics = hx::Class_obj::dupFunctions(sStaticFields);
	__mClass->mMembers = hx::Class_obj::dupFunctions(0 /* sMemberFields */);
	__mClass->mCanCast = hx::TCanCast< Main_obj >;
#ifdef HXCPP_VISIT_ALLOCS
	__mClass->mVisitFunc = sVisitStatics;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mMemberStorageInfo = sMemberStorageInfo;
#endif
#ifdef HXCPP_SCRIPTABLE
	__mClass->mStaticStorageInfo = sStaticStorageInfo;
#endif
	hx::RegisterClass(__mClass->mName, __mClass);
}

