#include <hxcpp.h>

#ifndef INCLUDED_haxe_macro_ComplexType
#include <haxe/macro/ComplexType.h>
#endif
#ifndef INCLUDED_haxe_macro_ExprDef
#include <haxe/macro/ExprDef.h>
#endif
#ifndef INCLUDED_haxe_macro_Unop
#include <haxe/macro/Unop.h>
#endif
#ifndef INCLUDED_haxe_macro_Binop
#include <haxe/macro/Binop.h>
#endif
#ifndef INCLUDED_haxe_macro_Constant
#include <haxe/macro/Constant.h>
#endif
#ifndef INCLUDED_sys_io_File
#include <sys/io/File.h>
#endif
#ifndef INCLUDED_haxe_Log
#include <haxe/Log.h>
#endif
#ifndef INCLUDED_EReg
#include <EReg.h>
#endif
#ifndef INCLUDED_tryOut_packageLevel02_packageLevel03_DeeplyRootedClass
#include <tryOut/packageLevel02/packageLevel03/DeeplyRootedClass.h>
#endif
#ifndef INCLUDED_tryOut_TryOut
#include <tryOut/TryOut.h>
#endif
#ifndef INCLUDED_sys_io_FileInput
#include <sys/io/FileInput.h>
#endif
#ifndef INCLUDED_haxe_io_Input
#include <haxe/io/Input.h>
#endif
#ifndef INCLUDED_haxe_io_Eof
#include <haxe/io/Eof.h>
#endif
#ifndef INCLUDED_expresso_Options
#include <expresso/Options.h>
#endif
#ifndef INCLUDED_expresso_MasterCollector
#include <expresso/MasterCollector.h>
#endif
#ifndef INCLUDED_expresso_ExpressionParser
#include <expresso/ExpressionParser.h>
#endif
#ifndef INCLUDED_StringBuf
#include <StringBuf.h>
#endif
#ifndef INCLUDED_Std
#include <Std.h>
#endif
#ifndef INCLUDED_Main
#include <Main.h>
#endif
#ifndef INCLUDED_cpp_Lib
#include <cpp/Lib.h>
#endif

void __files__boot();

void __boot_all()
{
__files__boot();
hx::RegisterResources( hx::GetResources() );
::haxe::macro::ComplexType_obj::__register();
::haxe::macro::ExprDef_obj::__register();
::haxe::macro::Unop_obj::__register();
::haxe::macro::Binop_obj::__register();
::haxe::macro::Constant_obj::__register();
::sys::io::File_obj::__register();
::haxe::Log_obj::__register();
::EReg_obj::__register();
::tryOut::packageLevel02::packageLevel03::DeeplyRootedClass_obj::__register();
::tryOut::TryOut_obj::__register();
::sys::io::FileInput_obj::__register();
::haxe::io::Input_obj::__register();
::haxe::io::Eof_obj::__register();
::expresso::Options_obj::__register();
::expresso::MasterCollector_obj::__register();
::expresso::ExpressionParser_obj::__register();
::StringBuf_obj::__register();
::Std_obj::__register();
::Main_obj::__register();
::cpp::Lib_obj::__register();
::haxe::macro::ComplexType_obj::__boot();
::haxe::macro::ExprDef_obj::__boot();
::haxe::macro::Unop_obj::__boot();
::haxe::macro::Binop_obj::__boot();
::haxe::macro::Constant_obj::__boot();
::EReg_obj::__boot();
::haxe::Log_obj::__boot();
::sys::io::File_obj::__boot();
}

