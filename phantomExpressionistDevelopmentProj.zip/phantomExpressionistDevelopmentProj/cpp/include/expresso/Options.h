#ifndef INCLUDED_expresso_Options
#define INCLUDED_expresso_Options

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(expresso,Options)
namespace expresso{


class HXCPP_CLASS_ATTRIBUTES  Options_obj : public hx::Object{
	public:
		typedef hx::Object super;
		typedef Options_obj OBJ_;
		Options_obj();
		Void __construct();

	public:
		inline void *operator new( size_t inSize, bool inContainer=false,const char *inName="expresso.Options")
			{ return hx::Object::operator new(inSize,inContainer,inName); }
		static hx::ObjectPtr< Options_obj > __new();
		static Dynamic __CreateEmpty();
		static Dynamic __Create(hx::DynamicArray inArgs);
		//~Options_obj();

		HX_DO_RTTI_ALL;
		Dynamic __Field(const ::String &inString, hx::PropertyAccess inCallProp);
		Dynamic __SetField(const ::String &inString,const Dynamic &inValue, hx::PropertyAccess inCallProp);
		static bool __SetStatic(const ::String &inString, Dynamic &ioValue, hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		::String __ToString() const { return HX_HCSTRING("Options","\x3e","\x5b","\x4f","\xad"); }

		bool threadTracking;
		virtual bool get_threadTracking( );
		Dynamic get_threadTracking_dyn();

		virtual bool set_threadTracking( bool newThreadTracking);
		Dynamic set_threadTracking_dyn();

		bool justForTestingPurposes;
		virtual Void setOptions( Array< ::String > options);
		Dynamic setOptions_dyn();

};

} // end namespace expresso

#endif /* INCLUDED_expresso_Options */ 
