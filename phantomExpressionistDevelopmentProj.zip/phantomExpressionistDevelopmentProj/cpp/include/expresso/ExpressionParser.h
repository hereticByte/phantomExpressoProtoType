#ifndef INCLUDED_expresso_ExpressionParser
#define INCLUDED_expresso_ExpressionParser

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(expresso,ExpressionParser)
namespace expresso{


class HXCPP_CLASS_ATTRIBUTES  ExpressionParser_obj : public hx::Object{
	public:
		typedef hx::Object super;
		typedef ExpressionParser_obj OBJ_;
		ExpressionParser_obj();
		Void __construct();

	public:
		inline void *operator new( size_t inSize, bool inContainer=false,const char *inName="expresso.ExpressionParser")
			{ return hx::Object::operator new(inSize,inContainer,inName); }
		static hx::ObjectPtr< ExpressionParser_obj > __new();
		static Dynamic __CreateEmpty();
		static Dynamic __Create(hx::DynamicArray inArgs);
		//~ExpressionParser_obj();

		HX_DO_RTTI_ALL;
		static void __register();
		::String __ToString() const { return HX_HCSTRING("ExpressionParser","\xb7","\x40","\x98","\x49"); }

};

} // end namespace expresso

#endif /* INCLUDED_expresso_ExpressionParser */ 
