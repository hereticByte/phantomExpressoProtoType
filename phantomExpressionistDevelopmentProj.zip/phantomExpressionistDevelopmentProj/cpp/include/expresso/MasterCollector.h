#ifndef INCLUDED_expresso_MasterCollector
#define INCLUDED_expresso_MasterCollector

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS0(EReg)
HX_DECLARE_CLASS1(expresso,MasterCollector)
HX_DECLARE_CLASS1(expresso,Options)
HX_DECLARE_CLASS2(haxe,macro,ExprDef)
namespace expresso{


class HXCPP_CLASS_ATTRIBUTES  MasterCollector_obj : public hx::Object{
	public:
		typedef hx::Object super;
		typedef MasterCollector_obj OBJ_;
		MasterCollector_obj();
		Void __construct();

	public:
		inline void *operator new( size_t inSize, bool inContainer=true,const char *inName="expresso.MasterCollector")
			{ return hx::Object::operator new(inSize,inContainer,inName); }
		static hx::ObjectPtr< MasterCollector_obj > __new();
		static Dynamic __CreateEmpty();
		static Dynamic __Create(hx::DynamicArray inArgs);
		//~MasterCollector_obj();

		HX_DO_RTTI_ALL;
		Dynamic __Field(const ::String &inString, hx::PropertyAccess inCallProp);
		static bool __GetStatic(const ::String &inString, Dynamic &outValue, hx::PropertyAccess inCallProp);
		Dynamic __SetField(const ::String &inString,const Dynamic &inValue, hx::PropertyAccess inCallProp);
		static bool __SetStatic(const ::String &inString, Dynamic &ioValue, hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		::String __ToString() const { return HX_HCSTRING("MasterCollector","\x2b","\x88","\x63","\x51"); }

		::String compilerString;
		::haxe::macro::ExprDef lastIdentifiedLandmark;
		virtual ::haxe::macro::ExprDef get_lastIdentifiedLandmark( );
		Dynamic get_lastIdentifiedLandmark_dyn();

		virtual ::haxe::macro::ExprDef set_lastIdentifiedLandmark( ::haxe::macro::ExprDef newLandmark);
		Dynamic set_lastIdentifiedLandmark_dyn();

		Dynamic positionInfo;
		virtual Dynamic get_positionInfo( );
		Dynamic get_positionInfo_dyn();

		virtual Dynamic set_positionInfo( Dynamic newPositionInfo);
		Dynamic set_positionInfo_dyn();

		::expresso::Options globalOptions;
		virtual ::expresso::Options get_globalOptions( );
		Dynamic get_globalOptions_dyn();

		Array< ::String > classPaths;
		virtual Array< ::String > get_classPaths( );
		Dynamic get_classPaths_dyn();

		Array< ::Dynamic > classPathsEReg;
		virtual Array< ::Dynamic > get_classPathsEReg( );
		Dynamic get_classPathsEReg_dyn();

		Array< ::Dynamic > positionsEreg;
		virtual Array< ::Dynamic > get_positionsEreg( );
		Dynamic get_positionsEreg_dyn();

		cpp::ArrayBase unhandledExpressions;
		virtual cpp::ArrayBase get_unhandledExpressions( );
		Dynamic get_unhandledExpressions_dyn();

		virtual Void storeUnhandledExpression( Dynamic item);
		Dynamic storeUnhandledExpression_dyn();

		virtual Dynamic resetPosition( );
		Dynamic resetPosition_dyn();

		virtual bool loadPositionToObj( Dynamic position,::String fieldName);
		Dynamic loadPositionToObj_dyn();

		static Void setGlobalOptions( Array< ::String > options);
		static Dynamic setGlobalOptions_dyn();

		static Void setClassPaths( Array< ::String > newClassPaths);
		static Dynamic setClassPaths_dyn();

		static ::expresso::MasterCollector _INSTANCE;
		static ::expresso::MasterCollector get_instance( );
		static Dynamic get_instance_dyn();

};

} // end namespace expresso

#endif /* INCLUDED_expresso_MasterCollector */ 
