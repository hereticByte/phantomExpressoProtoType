#ifndef INCLUDED_tryOut_TryOut
#define INCLUDED_tryOut_TryOut

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS1(tryOut,TryOut)
namespace tryOut{


class HXCPP_CLASS_ATTRIBUTES  TryOut_obj : public hx::Object{
	public:
		typedef hx::Object super;
		typedef TryOut_obj OBJ_;
		TryOut_obj();
		Void __construct(int _int,Float _float,::String string);

	public:
		inline void *operator new( size_t inSize, bool inContainer=true,const char *inName="tryOut.TryOut")
			{ return hx::Object::operator new(inSize,inContainer,inName); }
		static hx::ObjectPtr< TryOut_obj > __new(int _int,Float _float,::String string);
		static Dynamic __CreateEmpty();
		static Dynamic __Create(hx::DynamicArray inArgs);
		//~TryOut_obj();

		HX_DO_RTTI_ALL;
		Dynamic __Field(const ::String &inString, hx::PropertyAccess inCallProp);
		static bool __GetStatic(const ::String &inString, Dynamic &outValue, hx::PropertyAccess inCallProp);
		Dynamic __SetField(const ::String &inString,const Dynamic &inValue, hx::PropertyAccess inCallProp);
		static bool __SetStatic(const ::String &inString, Dynamic &ioValue, hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		void __Mark(HX_MARK_PARAMS);
		void __Visit(HX_VISIT_PARAMS);
		::String __ToString() const { return HX_HCSTRING("TryOut","\x33","\x9a","\xdf","\x89"); }

		int _int;
		Float _float;
		::String string;
		virtual int doubleCurrentInteger( );
		Dynamic doubleCurrentInteger_dyn();

		virtual Float multiplyTwoFloats( Float float01,Float float02);
		Dynamic multiplyTwoFloats_dyn();

		static Void tollFn( );
		static Dynamic tollFn_dyn();

		static Void executeVoidFn( Dynamic voidFn);
		static Dynamic executeVoidFn_dyn();

};

} // end namespace tryOut

#endif /* INCLUDED_tryOut_TryOut */ 
