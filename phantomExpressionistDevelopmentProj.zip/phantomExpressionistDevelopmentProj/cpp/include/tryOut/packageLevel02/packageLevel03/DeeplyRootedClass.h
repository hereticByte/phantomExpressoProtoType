#ifndef INCLUDED_tryOut_packageLevel02_packageLevel03_DeeplyRootedClass
#define INCLUDED_tryOut_packageLevel02_packageLevel03_DeeplyRootedClass

#ifndef HXCPP_H
#include <hxcpp.h>
#endif

HX_DECLARE_CLASS3(tryOut,packageLevel02,packageLevel03,DeeplyRootedClass)
namespace tryOut{
namespace packageLevel02{
namespace packageLevel03{


class HXCPP_CLASS_ATTRIBUTES  DeeplyRootedClass_obj : public hx::Object{
	public:
		typedef hx::Object super;
		typedef DeeplyRootedClass_obj OBJ_;
		DeeplyRootedClass_obj();
		Void __construct(int fantastisch,int toll,Dynamic optional);

	public:
		inline void *operator new( size_t inSize, bool inContainer=false,const char *inName="tryOut.packageLevel02.packageLevel03.DeeplyRootedClass")
			{ return hx::Object::operator new(inSize,inContainer,inName); }
		static hx::ObjectPtr< DeeplyRootedClass_obj > __new(int fantastisch,int toll,Dynamic optional);
		static Dynamic __CreateEmpty();
		static Dynamic __Create(hx::DynamicArray inArgs);
		//~DeeplyRootedClass_obj();

		HX_DO_RTTI_ALL;
		Dynamic __Field(const ::String &inString, hx::PropertyAccess inCallProp);
		Dynamic __SetField(const ::String &inString,const Dynamic &inValue, hx::PropertyAccess inCallProp);
		static bool __SetStatic(const ::String &inString, Dynamic &ioValue, hx::PropertyAccess inCallProp);
		void __GetFields(Array< ::String> &outFields);
		static void __register();
		::String __ToString() const { return HX_HCSTRING("DeeplyRootedClass","\x1e","\xae","\xcc","\x1a"); }

		int fantastisch;
		int toll;
		bool optional;
		virtual Void deeplyRootedMethod( );
		Dynamic deeplyRootedMethod_dyn();

};

} // end namespace tryOut
} // end namespace packageLevel02
} // end namespace packageLevel03

#endif /* INCLUDED_tryOut_packageLevel02_packageLevel03_DeeplyRootedClass */ 
